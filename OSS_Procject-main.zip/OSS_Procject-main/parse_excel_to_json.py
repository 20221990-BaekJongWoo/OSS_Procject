"""
엑셀 데이터를 menu_index.json 형식으로 변환하는 스크립트
"""
import pandas as pd
import json
import os
from pathlib import Path

def classify_menu_category(menu_name):
    """메뉴 이름으로 카테고리 분류"""
    menu_lower = menu_name.lower()
    
    # 한식 세부 카테고리
    stew_keywords = ['찌개', '청국장', '순두부']
    soup_keywords = ['탕', '곰탕', '뼈해장국', '흑염소탕', '어글탕', '매운탕', '어죽', '백숙', '추어탕', '복국', '어묵탕', '복어국', '곱도리탕', '알탕', '골뱅이탕', '해물탕', '새우탕', '올갱이해장국', '올갱이국', '콩나물탕', '게국지', '소양탕', '다슬기해장국', '황태해장국', '해신탕', '닭도리탕', '아구탕', '아귀찜', '알찜', '대게찜', '뼈다귀탕', '알곤이탕', '양평해장국', '내장탕', '도가니탕', '복지리', '소고기해장국', '시래기국', '대구뽈찜', '장어탕', '대구탕', '대구뽈탕', '생태탕', '명태탕', '오리탕', '생태찌개', '동태찌개', '오징어찌개', '간재미찌개']
    rice_soup_keywords = ['국밥', '해장국', '선지해장국', '수육국밥', '소머리국밥', '시래기국밥', '올갱이국밥', '우거지국밥', '콩나물해장국', '우거지해장국']
    stir_fry_keywords = ['볶음', '불고기', '라볶이', '두부두루치기', '두루치기', '쫄데기볶음', '주물럭', '철판볶음밥', '닭볶음탕']
    grill_keywords = ['구이', '갈비']
    bibimbap_keywords = ['비빔밥', '덮밥', '돌솥비빔밥', '육회비빔밥', '곱창덮밥', '장조림덮밥', '뚝배기불고기']
    noodle_keywords = ['칼국수', '잔치국수', '냉면', '비빔냉면', '콩국수', '라면', '막국수', '쫄면', '밀면', '수제비', '칼제비']
    rice_keywords = ['김밥', '도시락', '컵밥', '곤드레밥', '쌈밥', '돌솥밥', '솥밥', '밥버거', '주먹밥', '묵밥', '콩나물밥', '톳밥']
    pancake_keywords = ['파전', '해물파전', '빈대떡', '전', '육전', '모듬전', '만두전골', '두부전골', '쫄데기전골', '조개전골', '꼬막무침', '꼬막비빔밥']
    raw_fish_keywords = ['회', '물회', '회덮밥', '생선구이', '생선조림', '명태조림', '동태조림', '간재미무침', '간재미찌개', '육사시미', '전복구이', '대하구이', '문어구이', '게장', '간장게장', '게국지']
    jeongol_keywords = ['전골', '곱창전골', '만두전골', '두부전골', '쫄데기전골', '조개전골', '흑염소전골']
    health_keywords = ['보양식', '삼합', '백숙', '오리백숙', '닭백숙', '도토리묵', '만두', '죽', '뼈다귀탕', '도가니탕', '복지리', '삼계탕', '감자탕', '곰탕', '설렁탕', '육개장', '갈비탕']
    anju_keywords = ['안주', '족발', '보쌈', '닭발', '오돌뼈', '세꼬시', '먹태', '쥐포', '닭똥집', '골뱅이무침', '낙지볶음', '쭈꾸미볶음', '쭈꾸미', '낙곱새', '코다리조림', '갈치조림', '고등어조림', '갈치구이', '고등어', '갈치', '명태조림', '명태탕', '동태찜', '동태탕', '생태찌개', '생태탕', '오징어찌개', '오징어회', '오징어볶음', '쭈꾸미', '낙지볶음', '문어구이', '전복구이', '대하구이', '게장', '간장게장', '게국지', '해물모둠', '조개구이', '산낙지', '꼼장어', '꼬막무침', '꼬막비빔밥', '골뱅이소면', '골뱅이탕', '골뱅이무침', '낙곱새', '낙지볶음', '쭈꾸미볶음', '쭈꾸미', '해물탕', '새우탕', '해물모둠', '조개구이', '산낙지', '전복구이', '대하구이', '문어구이', '게장', '간장게장', '게국지', '물회', '회덮밥', '육사시미', '생선구이', '생선조림', '명태조림', '동태조림', '간재미무침', '간재미찌개', '전복구이', '대하구이', '문어구이']
    snack_keywords = ['분식', '떡볶이', '라볶이', '순대', '오뎅', '어묵', '튀김', '호떡', '빙수', '도너츠', '꽈배기', '빙떡', '또띠아', '김밥', '꼬마김밥', '도시락', '컵밥', '곤드레밥', '쌈밥', '돌솥밥', '솥밥', '밥버거', '주먹밥', '묵밥', '콩나물밥', '톳밥', '떡', '한과', '폐백음식', '전통차', '다과', '전가복', '채묵', '묵무침', '반찬', '장어', '민물장어']
    
    if any(kw in menu_lower for kw in stew_keywords):
        return 'korean_stew'
    elif any(kw in menu_lower for kw in soup_keywords):
        return 'korean_soup'
    elif any(kw in menu_lower for kw in rice_soup_keywords):
        return 'korean_rice_soup'
    elif any(kw in menu_lower for kw in stir_fry_keywords):
        return 'korean_stir_fry'
    elif any(kw in menu_lower for kw in grill_keywords):
        return 'korean_grill'
    elif any(kw in menu_lower for kw in bibimbap_keywords):
        return 'korean_bibimbap'
    elif any(kw in menu_lower for kw in noodle_keywords):
        return 'korean_noodle'
    elif any(kw in menu_lower for kw in rice_keywords):
        return 'korean_rice'
    elif any(kw in menu_lower for kw in pancake_keywords):
        return 'korean_pancake'
    elif any(kw in menu_lower for kw in raw_fish_keywords):
        return 'korean_raw_fish'
    elif any(kw in menu_lower for kw in jeongol_keywords):
        return 'korean_jeongol'
    elif any(kw in menu_lower for kw in health_keywords):
        return 'korean_health'
    elif any(kw in menu_lower for kw in anju_keywords):
        return 'korean_anju'
    elif any(kw in menu_lower for kw in snack_keywords):
        return 'korean_snack'
    
    # 중식
    chinese_keywords = ['짜장', '짬뽕', '볶음밥', '마파두부', '탕수육', '깐풍기', '유산슬', '양장피', '양전골', '울면', '우육면', '사천', '마라', '딤섬', '멘보샤', '꿔바로우', '라조기', '유린기', '고추잡채', '동파육', '징기스칸', '잡채밥', '북경오리', '양꼬치']
    if any(kw in menu_lower for kw in chinese_keywords):
        return 'chinese'
    
    # 일식
    japanese_keywords = ['초밥', '스시', '라멘', '우동', '돈까스', '규동', '가츠동', '오야코동', '텐동', '카레', '나베', '샤브샤브', '스키야키', '오코노미야키', '타코야키', '오므라이스', '오뎅', '사시미', '회', '연어', '참치', '장어', '우나기', '가라아게', '야키토리', '야키소바', '소바', '우메보시', '미소시루', '된장국', '일본식']
    if any(kw in menu_lower for kw in japanese_keywords):
        return 'japanese'
    
    # 동남아
    southeast_keywords = ['팟타이', '똠얌', '쌀국수', '분짜', '월남쌈', '반미', '카오팟', '팟카파오', '쏨땀', '라르브', '나시고랭', '인도네시아', '태국', '베트남', '싱가포르', '말레이시아', '필리핀']
    if any(kw in menu_lower for kw in southeast_keywords):
        return 'southeast'
    
    # 서양식
    western_keywords = ['파스타', '피자', '스테이크', '햄버거', '샐러드', '리조또', '라자냐', '뇨키', '그라탕', '오믈렛', '오므라이스', '샌드위치', '브런치', '와플', '팬케이크', '프렌치토스트', '치킨', '닭강정', '치즈스틱', '나초', '타코', '부리토', '케사디야', '퀘사디야', '멕시칸', '이탈리안', '프렌치', '아메리칸']
    if any(kw in menu_lower for kw in western_keywords):
        return 'western'
    
    # 기본값: 한식 기타
    return 'korean_other'

def parse_excel_to_menu_index(excel_path, output_path=None):
    """엑셀 파일을 읽어서 menu_index.json 형식으로 변환"""
    
    print(f"📖 엑셀 파일 읽는 중: {excel_path}")
    
    # 엑셀 파일 읽기
    try:
        df = pd.read_excel(excel_path, engine='openpyxl')
    except Exception as e:
        print(f"❌ 엑셀 파일 읽기 실패: {e}")
        print("💡 openpyxl 설치 필요: pip install openpyxl")
        return None
    
    print(f"✅ 엑셀 파일 읽기 완료: {len(df)}개 행, {len(df.columns)}개 열")
    print(f"📋 컬럼 목록: {list(df.columns)}")
    
    # 첫 번째 행 확인 (헤더)
    print(f"\n📊 첫 5개 행 미리보기:")
    print(df.head())
    
    # 가게명 컬럼 찾기 (첫 번째 컬럼 또는 '가게명', '가게이름' 등)
    place_name_col = None
    for col in df.columns:
        col_lower = str(col).lower()
        if any(keyword in col_lower for keyword in ['가게', '식당', '상호', '업소', 'place', 'restaurant', 'name']):
            place_name_col = col
            break
    
    if place_name_col is None:
        place_name_col = df.columns[0]  # 첫 번째 컬럼 사용
    
    print(f"\n🏪 가게명 컬럼: {place_name_col}")
    
    # 메뉴 컬럼 찾기 (가게명 제외한 나머지)
    menu_columns = [col for col in df.columns if col != place_name_col]
    print(f"🍽️ 메뉴 컬럼 개수: {len(menu_columns)}")
    
    # menu_index 구조 생성
    menu_index = {}
    
    # 각 메뉴에 대해
    for menu_col in menu_columns:
        menu_name = str(menu_col).strip()
        
        # 해당 메뉴가 있는 가게들 찾기 (값이 1인 경우)
        # 숫자 1, 문자열 "1", True 등 모두 처리
        places_with_menu = []
        for idx, row in df.iterrows():
            value = row[menu_col]
            # 값이 1, "1", True, "True" 등인 경우
            if pd.notna(value) and (
                value == 1 or 
                str(value).strip() == "1" or 
                value is True or 
                str(value).lower() == "true"
            ):
                place_name = str(row[place_name_col]).strip()
                if place_name and place_name != "nan":
                    places_with_menu.append(place_name)
        
        if places_with_menu:
            # 카테고리 분류
            category = classify_menu_category(menu_name)
            
            if category not in menu_index:
                menu_index[category] = {}
            
            # 중복 제거 및 정렬
            places_with_menu = sorted(list(set(places_with_menu)))
            menu_index[category][menu_name] = places_with_menu
            
            print(f"  ✓ {menu_name}: {len(places_with_menu)}개 가게 ({category})")
    
    # 결과 통계
    print(f"\n📊 변환 결과:")
    print(f"  - 총 카테고리: {len(menu_index)}개")
    for cat, menus in menu_index.items():
        print(f"  - {cat}: {len(menus)}개 메뉴")
    
    # JSON으로 저장
    if output_path is None:
        output_path = "menu_index_from_excel.json"
    
    output_data = {"menu_index": menu_index}
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2)
    
    print(f"\n✅ 변환 완료: {output_path}")
    print(f"📁 파일 크기: {os.path.getsize(output_path) / 1024:.2f} KB")
    
    return output_path

if __name__ == "__main__":
    # 현재 디렉토리에서 엑셀 파일 찾기
    current_dir = Path(__file__).parent
    excel_files = list(current_dir.glob("*.xlsx"))
    
    if not excel_files:
        print(f"❌ 엑셀 파일을 찾을 수 없습니다.")
        print(f"💡 현재 디렉토리: {current_dir}")
        print("💡 엑셀 파일(.xlsx)을 현재 디렉토리에 넣어주세요.")
    else:
        # 첫 번째 엑셀 파일 사용
        excel_path = excel_files[0]
        print(f"📁 발견된 엑셀 파일: {excel_path.name}")
        parse_excel_to_menu_index(excel_path)

