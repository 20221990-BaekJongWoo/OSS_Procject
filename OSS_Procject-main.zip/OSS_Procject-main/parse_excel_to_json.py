# -*- coding: utf-8 -*-
"""
엑셀 데이터를 menu_index.json 형식으로 변환하는 스크립트
"""
import pandas as pd
import json
import os
from pathlib import Path

def classify_menu_category(menu_name):
    """메뉴 이름으로 카테고리 분류"""
    menu_lower = menu_name.lower()
    
    # 한식 세부 카테고리
    stew_keywords = ['찌개', '청국장', '순두부']
    soup_keywords = ['탕', '고기', '뼈해장국', '육개장', '어글탕', '매운탕', '어죽', '백숙', '추어탕', '복국', '어무탕', '복어국', '곰도리탕', '알탕', '골뱅이탕', '해물탕', '새우탕', '올갱이해장국', '올갱이국', '콩나물탕', '게국지', '소양탕', '시래기해장국', '황태해장국', '해신탕', '닭볶음탕', '아구탕', '아귀찜', '알찜', '대게찜', '뼈다귀탕', '알곤이탕', '양평해장국', '내장탕', '도가니탕', '복지리', '소고기해장국', '시래기국', '대구뽈찜', '장어탕', '대구탕', '대구뽈탕', '생태탕', '명태탕', '오리탕', '생태찌개', '동태찌개', '오징어찌개', '간재미찌개']
    rice_soup_keywords = ['국밥', '해장국', '선지해장국', '수육국밥', '소머리국밥', '시래기국밥', '올갱이국밥', '우거지국밥', '콩나물해장국', '우거지해장국']
    stir_fry_keywords = ['볶음', '불고기', '라볶이', '두부두루치기', '두루치기', '쭈꾸미볶음', '주물럭', '철판볶음밥', '닭볶음탕']
    grill_keywords = ['구이', '갈비']
    bibimbap_keywords = ['비빔밥', '덮밥', '돌솥비빔밥', '육회비빔밥', '공작덮밥', '장조림덮밥', '뚝배기불고기']
    noodle_keywords = ['칼국수', '잔치국수', '냉면', '비빔냉면', '콩국수', '라면', '막국수', '쫄면', '밀면', '수제비', '칼제비']
    rice_keywords = ['김밥', '도시락', '컵밥', '곤드레밥', '쌈밥', '돌솥밥', '솥밥', '밥버거', '주먹밥', '묵밥', '콩나물밥', '톳밥']
    pancake_keywords = ['파전', '해물파전', '빈대떡', '전', '육전', '모듬전', '만두전골', '두부전골', '쭈꾸미전골', '조개전골', '꼬막무침', '꼬막비빔밥']
    raw_fish_keywords = ['회', '물회', '회덮밥', '생선구이', '생선조림', '명태조림', '동태조림', '간재미무침', '간재미찌개', '육사시미', '전복구이', '대하구이', '문어구이', '게장', '간장게장', '게국지']
    jeongol_keywords = ['전골', '곱창전골', '만두전골', '두부전골', '쭈꾸미전골', '조개전골', '육개장전골']
    health_keywords = ['보양식', '삼합', '백숙', '오리백숙', '닭백숙', '도토리묵', '만두', '죽', '뼈다귀탕', '도가니탕', '복지리', '삼계탕', '감자탕', '고기', '설렁탕', '육개장', '갈비탕']
    anju_keywords = ['안주', '족발', '보쌈', '닭발', '오돌뼈', '세꼬시', '먹태', '쥐포', '닭똥집', '골뱅이무침', '낙지볶음', '쭈꾸미볶음', '쭈꾸미', '낙곱새', '코다리조림', '갈치조림', '고등어조림', '갈치구이', '고등어', '갈치', '명태조림', '명태탕', '동태찜', '동태탕', '생태찌개', '생태탕', '오징어찌개', '오징어회', '오징어볶음', '쭈꾸미', '낙지볶음', '문어구이', '전복구이', '대하구이', '게장', '간장게장', '게국지', '해물모듬', '조개구이', '산낙지', '꼼장어', '꼬막무침', '꼬막비빔밥', '골뱅이소면', '골뱅이탕', '골뱅이무침', '낙곱새', '낙지볶음', '쭈꾸미볶음', '쭈꾸미', '해물탕', '새우탕', '해물모듬', '조개구이', '산낙지', '전복구이', '대하구이', '문어구이', '게장', '간장게장', '게국지', '물회', '회덮밥', '육사시미', '생선구이', '생선조림', '명태조림', '동태조림', '간재미무침', '간재미찌개', '전복구이', '대하구이', '문어구이']
    snack_keywords = ['분식', '떡볶이', '라볶이', '순대', '오뎅', '어묵', '튀김', '호떡', '빙수', '도너츠', '꽈배기', '빙떡', '또띠아', '김밥', '꼬마김밥', '도시락', '컵밥', '곤드레밥', '쌈밥', '돌솥밥', '솥밥', '밥버거', '주먹밥', '묵밥', '콩나물밥', '톳밥', '떡', '한과', '폐백음식', '전통차', '다과', '전가복', '치킨', '무무침', '반찬', '장어', '민물장어']
    
    if any(kw in menu_lower for kw in stew_keywords):
        return 'korean_stew'
    elif any(kw in menu_lower for kw in soup_keywords):
        return 'korean_soup'
    elif any(kw in menu_lower for kw in rice_soup_keywords):
        return 'korean_rice_soup'
    elif any(kw in menu_lower for kw in stir_fry_keywords):
        return 'korean_stir_fry'
    elif any(kw in menu_lower for kw in grill_keywords):
        return 'korean_grill'
    elif any(kw in menu_lower for kw in bibimbap_keywords):
        return 'korean_bibimbap'
    elif any(kw in menu_lower for kw in noodle_keywords):
        return 'korean_noodle'
    elif any(kw in menu_lower for kw in rice_keywords):
        return 'korean_rice'
    elif any(kw in menu_lower for kw in pancake_keywords):
        return 'korean_pancake'
    elif any(kw in menu_lower for kw in raw_fish_keywords):
        return 'korean_raw_fish'
    elif any(kw in menu_lower for kw in jeongol_keywords):
        return 'korean_jeongol'
    elif any(kw in menu_lower for kw in health_keywords):
        return 'korean_health'
    elif any(kw in menu_lower for kw in anju_keywords):
        return 'korean_anju'
    elif any(kw in menu_lower for kw in snack_keywords):
        return 'korean_snack'
    
    # 중식
    chinese_keywords = ['짜장', '짬뽕', '볶음밥', '마파두부', '탕수육', '깐풍기', '유산슬', '양장피', '양전골', '울면', '우육면', '사천', '마라', '딤섬', '멘보샤', '꿔바로우', '라조기', '유린기', '고추잡채', '동파육', '징기스칸', '잡채밥', '북경오리', '양꼬치']
    if any(kw in menu_lower for kw in chinese_keywords):
        return 'chinese'
    
    # 일식
    japanese_keywords = ['초밥', '스시', '라멘', '우동', '돈까스', '규동', '가츠동', '오야코동', '텐동', '카레', '나베', '샤브샤브', '스키야키', '오코노미야키', '타코야키', '오무라이스', '오뎅', '사시미', '회', '연어', '참치', '장어', '우나기', '가라아게', '야키토리', '야키소바', '소바', '우메보시', '미소시루', '된장국', '일본식']
    if any(kw in menu_lower for kw in japanese_keywords):
        return 'japanese'
    
    # 동남아
    southeast_keywords = ['팟타이', '똠얌', '쌀국수', '분짜', '월남쌈', '반미', '카오팟', '팟카파오', '푸팟퐁', '나시고랭', '미고랭', '인도네시아', '태국', '베트남', '싱가포르', '말레이시아', '필리핀']
    if any(kw in menu_lower for kw in southeast_keywords):
        return 'southeast'
    
    # 서양식
    western_keywords = ['파스타', '피자', '스테이크', '햄버거', '샐러드', '리조또', '라자냐', '뇨키', '그라탕', '오믈렛', '오무라이스', '샌드위치', '브런치', '와플', '팬케이크', '프렌치토스트', '치킨', '닭강정', '치즈스틱', '나초', '타코', '부리토', '퀘사디아', '파히타', '멕시치', '이탈리안', '프렌치', '아메리칸']
    if any(kw in menu_lower for kw in western_keywords):
        return 'western'
    
    # 기본값: 한식 기타
    return 'korean_other'

def parse_excel_to_menu_index(excel_path, category_override=None):
    """엑셀 파일을 읽어서 menu_index.json 형식으로 변환
    
    Args:
        excel_path: 엑셀 파일 경로
        category_override: 엑셀 파일명으로부터 카테고리를 자동 판단하거나, 직접 지정
    """
    
    print(f"📖 엑셀 파일 읽는 중: {excel_path}")
    
    # 엑셀 파일명으로부터 카테고리 판단
    excel_name = Path(excel_path).stem.lower()
    category_map = {
        '한식': 'korean',
        '중식': 'chinese',
        '일식': 'japanese',
        '서양식': 'western',
        '동남아': 'southeast',
        '기타': 'etc'
    }
    
    if category_override:
        file_category = category_override
    else:
        file_category = category_map.get(excel_name)
        if not file_category:
            # 파일명에 카테고리 정보가 없으면 자동 분류 사용
            file_category = None
    
    # 엑셀 파일 읽기
    try:
        df = pd.read_excel(excel_path, engine='openpyxl')
        
        # 모든 문자열 컬럼의 데이터를 UTF-8로 정규화
        for col in df.columns:
            if df[col].dtype == 'object':
                df[col] = df[col].apply(lambda x: 
                    str(x).encode('utf-8', errors='replace').decode('utf-8') 
                    if pd.notna(x) and isinstance(x, str) else x)
        
        # 컬럼명도 정규화
        df.columns = [str(col).encode('utf-8', errors='replace').decode('utf-8') for col in df.columns]
    except Exception as e:
        print(f"❌ 엑셀 파일 읽기 실패: {e}")
        print("💡 openpyxl 설치 필요: pip install openpyxl")
        return None
    
    print(f"✅ 엑셀 파일 읽기 완료: {len(df)}개 행, {len(df.columns)}개 열")
    if file_category:
        print(f"📖 카테고리: {file_category}")
    
    # 가게명 컬럼 찾기
    place_name_col = None
    for col in df.columns:
        col_lower = str(col).lower()
        if any(keyword in col_lower for keyword in ['가게', '식당', '상호', '업소', 'place', 'restaurant', 'name']):
            place_name_col = col
            break
    
    if place_name_col is None:
        place_name_col = df.columns[0]
    
    # 메뉴 컬럼 찾기
    menu_columns = [col for col in df.columns if col != place_name_col]
    
    # menu_index 구조 생성
    menu_index = {}
    # 프론트엔드용 구조도 생성
    frontend_korean = {}  # 한식 세부 카테고리별
    frontend_others = {}  # 다른 카테고리별
    
    # 각 메뉴에 대해
    for menu_col in menu_columns:
        menu_name = str(menu_col).strip()
        try:
            menu_name = menu_name.encode('utf-8', errors='ignore').decode('utf-8')
        except:
            pass
        
        # 해당 메뉴가 있는 가게들 찾기
        places_with_menu = []
        for idx, row in df.iterrows():
            value = row[menu_col]
            if pd.notna(value) and (
                value == 1 or 
                str(value).strip() == "1" or 
                value is True or 
                str(value).lower() == "true"
            ):
                place_name = str(row[place_name_col]).strip()
                try:
                    place_name = place_name.encode('utf-8', errors='ignore').decode('utf-8')
                except:
                    pass
                if place_name and place_name != "nan":
                    places_with_menu.append(place_name)
        
        if places_with_menu:
            # 카테고리 분류
            if file_category:
                # 파일명으로 카테고리가 정해진 경우
                if file_category == 'korean':
                    # 한식은 세부 카테고리 분류
                    category = classify_menu_category(menu_name)
                else:
                    # 다른 카테고리는 그대로 사용
                    category = file_category
            else:
                # 자동 분류
                category = classify_menu_category(menu_name)
            
            # 백엔드용 menu_index에 추가
            if category not in menu_index:
                menu_index[category] = {}
            places_with_menu = sorted(list(set(places_with_menu)))
            menu_index[category][menu_name] = places_with_menu
            
            # 프론트엔드용 구조에 추가
            menu_obj = {"id": menu_name, "label": menu_name}
            
            if category.startswith('korean_'):
                # 한식 세부 카테고리
                sub = category.replace('korean_', '')
                # 프론트엔드에서 사용하는 세부 카테고리명으로 매핑
                sub_mapping = {
                    'stew': 'stew',
                    'soup': 'stew',  # 탕류도 stew에 포함
                    'rice_soup': 'gukbap',
                    'stir_fry': 'stew',  # 볶음류는 stew에 포함 (조류)
                    'grill': 'grill',
                    'bibimbap': 'rice',
                    'noodle': 'noodle',
                    'rice': 'rice',
                    'pancake': 'seafood',  # 파전 등은 seafood에 포함
                    'raw_fish': 'seafood',
                    'jeongol': 'jeongol',
                    'health': 'health',
                    'anju': 'anju',
                    'snack': 'snack',
                    'other': 'rice'  # 기타는 rice에 포함
                }
                frontend_sub = sub_mapping.get(sub, 'rice')
                if frontend_sub not in frontend_korean:
                    frontend_korean[frontend_sub] = []
                frontend_korean[frontend_sub].append(menu_obj)
            else:
                # 다른 카테고리
                if category not in frontend_others:
                    frontend_others[category] = []
                frontend_others[category].append(menu_obj)
    
    return {
        'menu_index': menu_index,
        'frontend_korean': frontend_korean,
        'frontend_others': frontend_others
    }

if __name__ == "__main__":
    # 현재 디렉토리에서 엑셀 파일 찾기
    current_dir = Path(__file__).parent
    
    # 카테고리별 엑셀 파일 매핑
    category_files = {
        'korean': '한식.xlsx',
        'chinese': '중식.xlsx',
        'japanese': '일식.xlsx',
        'western': '서양식.xlsx',
        'southeast': '동남아.xlsx',
        'etc': '기타.xlsx'
    }
    
    # 모든 엑셀 파일 처리
    all_menu_index = {}
    all_frontend_korean = {}
    all_frontend_others = {}
    
    print("=" * 60)
    print("🚀 모든 엑셀 파일 처리 시작")
    print("=" * 60)
    
    for category, filename in category_files.items():
        excel_path = current_dir / filename
        if not excel_path.exists():
            print(f"⚠️  파일 없음: {filename} (건너뜀)")
            continue
        
        print(f"\n{'='*60}")
        print(f"📂 처리 중: {filename}")
        print(f"{'='*60}")
        
        result = parse_excel_to_menu_index(excel_path, category_override=category)
        if result:
            # 백엔드용 menu_index 병합
            for cat, menus in result['menu_index'].items():
                if cat not in all_menu_index:
                    all_menu_index[cat] = {}
                all_menu_index[cat].update(menus)
            
            # 프론트엔드용 구조 병합
            for sub, menus in result['frontend_korean'].items():
                if sub not in all_frontend_korean:
                    all_frontend_korean[sub] = []
                all_frontend_korean[sub].extend(menus)
            
            for cat, menus in result['frontend_others'].items():
                if cat not in all_frontend_others:
                    all_frontend_others[cat] = []
                all_frontend_others[cat].extend(menus)
    
    # 결과 저장
    print(f"\n{'='*60}")
    print("💾 결과 저장 중...")
    print(f"{'='*60}")
    
    # 1. 백엔드용 menu_index.json
    backend_path = current_dir / "backend" / "menu_index.json"
    backend_data = {"menu_index": all_menu_index}
    with open(backend_path, 'w', encoding='utf-8') as f:
        json.dump(backend_data, f, ensure_ascii=False, indent=2)
    print(f"✅ 백엔드: {backend_path}")
    print(f"   - 총 카테고리: {len(all_menu_index)}개")
    for cat, menus in all_menu_index.items():
        print(f"   - {cat}: {len(menus)}개 메뉴")
    
    # 2. 프론트엔드용 menu_korean.json
    frontend_korean_path = current_dir / "frontend" / "src" / "menu_korean.json"
    # 각 세부 카테고리별로 정렬
    sorted_korean = {k: sorted(v, key=lambda x: x['label']) for k, v in all_frontend_korean.items()}
    with open(frontend_korean_path, 'w', encoding='utf-8') as f:
        json.dump(sorted_korean, f, ensure_ascii=False, indent=2)
    print(f"✅ 프론트엔드 (한식): {frontend_korean_path}")
    print(f"   - 세부 카테고리: {len(sorted_korean)}개")
    for sub, menus in sorted_korean.items():
        print(f"   - {sub}: {len(menus)}개 메뉴")
    
    # 3. 프론트엔드용 menu_others.json
    frontend_others_path = current_dir / "frontend" / "src" / "menu_others.json"
    # 각 카테고리별로 정렬
    sorted_others = {k: sorted(v, key=lambda x: x['label']) for k, v in all_frontend_others.items()}
    with open(frontend_others_path, 'w', encoding='utf-8') as f:
        json.dump(sorted_others, f, ensure_ascii=False, indent=2)
    print(f"✅ 프론트엔드 (기타): {frontend_others_path}")
    print(f"   - 카테고리: {len(sorted_others)}개")
    for cat, menus in sorted_others.items():
        print(f"   - {cat}: {len(menus)}개 메뉴")
    
    # 4. 루트에 menu_index_from_excel.json도 저장 (호환성)
    root_path = current_dir / "menu_index_from_excel.json"
    with open(root_path, 'w', encoding='utf-8') as f:
        json.dump(backend_data, f, ensure_ascii=False, indent=2)
    print(f"✅ 루트: {root_path}")
    
    print(f"\n{'='*60}")
    print("🎉 모든 작업 완료!")
    print(f"{'='*60}")