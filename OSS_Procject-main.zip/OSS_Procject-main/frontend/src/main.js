// src/main.js

const $ = (s) => document.querySelector(s);

// 사운드 효과 함수
const audioContext = new (window.AudioContext || window.webkitAudioContext)();
function playTone(frequency, duration, type = 'sine', volume = 0.3) {
  try {
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = frequency;
    oscillator.type = type;
    
    gainNode.gain.setValueAtTime(0, audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(volume, audioContext.currentTime + 0.01);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + duration);
  } catch (e) {
    if (audioContext.state === 'suspended') {
      audioContext.resume();
    }
  }
}

function playClickSound(frequency = 800, volume = 0.2, duration = 0.05) {
  playTone(frequency, duration, 'sine', volume);
}

function playStartSound() {
  playTone(600, 0.15, 'sine', 0.4);
  setTimeout(() => playTone(800, 0.1, 'sine', 0.3), 100);
}

function playStopSound() {
  playTone(400, 0.2, 'sine', 0.4);
  setTimeout(() => playTone(300, 0.3, 'sine', 0.3), 150);
}

let MENUS_KOREAN = {};  
let MENUS_OTHERS = {};   

const CATEGORIES = ["korean", "chinese", "japanese", "southeast", "western", "etc"];

// -------------------------
// 좌표 보정
// -------------------------
// 잘못된 좌표와 올바른 좌표의 차이(오프셋) 계산
// 잘못된 좌표: (36.4511232, 127.4380288)
// 올바른 좌표: (36.454021, 127.422518)
const COORD_OFFSET_LAT = 36.454021 - 36.4511232;  // 위도 오프셋: 0.0028978
const COORD_OFFSET_LNG = 127.422518 - 127.4380288;  // 경도 오프셋: -0.0155108

function correctCoordinate(lat, lng) {
  /**
   * 좌표 보정: 계산된 위치(잘못된 위치)에서 오프셋을 적용하여 올바른 좌표로 변환
   * 위도는 +0.0028978, 경도는 -0.0155108을 더함
   * @param {number} lat - 위도
   * @param {number} lng - 경도
   * @returns {Object} {lat: number, lng: number} - 보정된 좌표
   */
  return {
    lat: lat + COORD_OFFSET_LAT,
    lng: lng + COORD_OFFSET_LNG
  };
}

let currentCategory = "korean";
let currentSubcategory = "grill";

const excluded = new Set();  // 전역 제외 메뉴 id 모음

// 추천 결과 저장 (검색 때 사용)
let lastRecoId = null;
let lastRecoCat = null;
let lastRecoSub = null;
let highlightedMenu = null; // 하이라이트할 메뉴 (추천 결과)
let recommendationMode = 'roulette'; // 추천 방식 (roulette, claw, scratch)

// 즐겨찾기
const FAV_KEY = 'fav_places_v1';
const favorites = new Set(JSON.parse(localStorage.getItem(FAV_KEY) || '[]'));

// 최근 검색
const RECENT_KEY = 'recent_searches_v1';
let recentSearches = JSON.parse(localStorage.getItem(RECENT_KEY) || '[]');

// 정렬/필터
let currentSort = 'distance';
let onlyFav = false;
let lastPlaces = [];
let lastGeo = null; // { x, y }

// 스킵 기능
const skipButton = $('#btn-skip');
let activeSkipHandler = null;
let pendingSkipRequest = false;

// 자동 제외
const autoExcludedMenuIds = new Set();

// 게임 전략
const gameStrategies = {};

// 전역 interval 관리
let globalRouletteInterval = null;

function updateGlobalInterval(interval) {
  if (globalRouletteInterval) {
    clearTimeout(globalRouletteInterval);
  }
  globalRouletteInterval = interval;
}

// 전역 변수: 카테고리 랜덤 결과 저장
let selectedCategoryFromRandom = null;

// id -> { cat, sub } 메타 정보 (백엔드 연동용/검색용)
const menuMeta = {};

// --------------------------
// 스킵 핸들러
// --------------------------
function setSkipHandler(handler) {
  activeSkipHandler = typeof handler === 'function' ? handler : null;
  if (skipButton) {
    skipButton.disabled = !activeSkipHandler;
  }
  if (activeSkipHandler && pendingSkipRequest) {
    pendingSkipRequest = false;
    skipButton.disabled = true;
    activeSkipHandler();
  } else if (!activeSkipHandler) {
    pendingSkipRequest = false;
  }
}

setSkipHandler(null);

function primeSkipButton() {
  if (!skipButton) return;
  pendingSkipRequest = false;
  skipButton.disabled = false;
}

// [Concept: Decorator (perf + logging)]
function withLogging(name, fn) {
  return async (...args) => {
    const start = performance.now?.() ?? Date.now();
    const result = await fn(...args);
    const elapsed = (performance.now?.() ?? Date.now()) - start;
    return result;
  };
}

// --------------------------
//  메뉴 JSON 두 개 로드
// --------------------------
async function loadMenus() {
  try {
    const [resKor, resOthers] = await Promise.all([
      fetch("/src/menu_korean.json"),
      fetch("/src/menu_others.json"),
    ]);

    MENUS_KOREAN = await resKor.json();
    MENUS_OTHERS = await resOthers.json();

    buildMenuMeta();
    renderCategoryOptions();
    renderSubcategoryOptions();
    renderChips();
    updateCategoryRandomButton();
  } catch (e) {
    console.error("❌ 메뉴 로드 실패:", e);
    $("#menu-chips").innerHTML = '<li class="muted">메뉴 데이터를 불러올 수 없습니다.</li>';
  }
}

// id → cat/sub 메타 정보 생성
function buildMenuMeta() {
  // 한식
  Object.entries(MENUS_KOREAN || {}).forEach(([sub, arr]) => {
    arr.forEach(m => {
      menuMeta[m.id] = { cat: "korean", sub };
    });
  });
  // 나머지
  Object.entries(MENUS_OTHERS || {}).forEach(([cat, arr]) => {
    arr.forEach(m => {
      menuMeta[m.id] = { cat, sub: null };
    });
  });
}

// --------------------------
// 카테고리 셀렉트 렌더링
// --------------------------
function renderCategoryOptions() {
  const sel = $("#category");
  sel.innerHTML = "";

  const labels = {
    korean: "한식",
    chinese: "중식",
    japanese: "일식",
    southeast: "동남아",
    western: "서양식",
    etc: "기타",
  };

  CATEGORIES.forEach(key => {
    const opt = document.createElement("option");
    opt.value = key;
    opt.textContent = labels[key] || key;
    sel.appendChild(opt);
  });

  sel.value = currentCategory;
}

// --------------------------
//한식 세부 카테고리 렌더링
// --------------------------
function renderSubcategoryOptions() {
  const subSel = $("#subcategory");
  const subLabel = $("#subcat-label");

  if (currentCategory !== "korean") {
    subSel.style.display = "none";
    subLabel.style.display = "none";
    return;
  }

  const keys = Object.keys(MENUS_KOREAN || {});
  if (!keys.length) {
    subSel.style.display = "none";
    subLabel.style.display = "none";
    return;
  }

  // 현재 서브카테고리 유효성 체크
  if (!MENUS_KOREAN[currentSubcategory]) {
    currentSubcategory = keys[0];
  }

  subSel.innerHTML = "";
  const subLabels = {
    grill: "구이류",
    stew: "찌개/탕",
    gukbap: "국밥류",
    noodle: "면류",
    jeongol: "전골",
    seafood: "해산물",
    snack: "분식/간단",
    health: "보양식",
    anju: "안주류",
    rice: "밥류",
    other: "기타",
};

  keys.forEach(key => {
    const opt = document.createElement("option");
    opt.value = key;
    opt.textContent = subLabels[key] || key;
    subSel.appendChild(opt);
  });

  subSel.value = currentSubcategory;
  subSel.style.display = "inline-block";
  subLabel.style.display = "inline-block";
}

// 카테고리 랜덤 버튼 표시/숨김 업데이트
function updateCategoryRandomButton() {
  const btnNormal = $("#btn-category-random");
  const btnKorean = $("#btn-category-random-korean");
  
  if (currentCategory === "korean") {
    if (btnNormal) btnNormal.style.display = "none";
    if (btnKorean) btnKorean.style.display = selectedCategoryFromRandom ? "none" : "inline-block";
  } else {
    if (btnNormal) btnNormal.style.display = selectedCategoryFromRandom ? "none" : "inline-block";
    if (btnKorean) btnKorean.style.display = "none";
  }
}

// --------------------------
// 현재 화면에 보여줄 메뉴 리스트
// --------------------------
function getVisibleMenuList() {
  if (currentCategory === "korean") {
    return MENUS_KOREAN[currentSubcategory] || [];
    } else {
    return MENUS_OTHERS[currentCategory] || [];
    }
  }
  
// --------------------------
// 칩 렌더링
// --------------------------
function renderChips() {
  const wrap = $("#menu-chips");
  wrap.innerHTML = "";

  const list = getVisibleMenuList();

  list.forEach(m => {
    const chip = document.createElement("button");
    chip.type = "button";
    chip.className = "chip";
    chip.textContent = m.label;
    chip.dataset.id = m.id;

    if (excluded.has(m.id)) chip.classList.add("excluded");
    
    // 하이라이트 상태 확인
    if (highlightedMenu === m.label) {
      chip.classList.add("highlight", "final");
    }

    chip.onclick = () => toggleChip(chip, m.id);
    wrap.appendChild(chip);
  });

  updateToggleAllButton();
}

// 개별 토글
function toggleChip(el, id) {
  if (excluded.has(id)) {
    excluded.delete(id);
    el.classList.remove("excluded");
  } else {
    excluded.add(id);
    el.classList.add("excluded");
    }
  updateToggleAllButton();
}

// --------------------------
// 전체 제외/해제 버튼
// --------------------------
$("#btn-toggle-all")?.addEventListener("click", () => {
  const list = getVisibleMenuList();
  const ids = list.map(m => m.id);
  const allExcluded = ids.length > 0 && ids.every(id => excluded.has(id));

    if (allExcluded) {
    ids.forEach(id => excluded.delete(id));
    } else {
    ids.forEach(id => excluded.add(id));
    }
    renderChips();
});

function updateToggleAllButton() {
  const btn = $("#btn-toggle-all");
  const list = getVisibleMenuList();
  const ids = list.map(m => m.id);
  const excludedCount = ids.filter(id => excluded.has(id)).length;
  const total = ids.length;
  btn.textContent = total > 0 && excludedCount >= total ? "전체 해제" : "전체 제외";
}

// --------------------------
// 사용 가능한 모든 메뉴 가져오기 (카테고리별)
// --------------------------
function getAllAvailableMenus() {
  const catCandidates = [];
  
  // 한식 전체 (세부 구분 없이)
  const korIds = Object.values(MENUS_KOREAN || {})
    .flat()
    .map(m => m.id)
    .filter(id => !excluded.has(id));
  if (korIds.length > 0) {
    catCandidates.push("korean");
  }

  // 나머지 카테고리
  Object.keys(MENUS_OTHERS || {}).forEach(cat => {
    const ids = (MENUS_OTHERS[cat] || [])
      .map(m => m.id)
      .filter(id => !excluded.has(id));
    if (ids.length > 0) {
      catCandidates.push(cat);
    }
  });

  return catCandidates;
}

// --------------------------
// 카테고리에서 사용 가능한 메뉴 가져오기
// --------------------------
function getAvailableMenusFromCategory(cat) {
  let candidates = [];
  
  if (cat === "korean") {
    // 한식이면 세부 구분 없이 전체 한식 메뉴에서 선택
    Object.entries(MENUS_KOREAN || {}).forEach(([sub, arr]) => {
      arr.forEach(m => {
        if (!excluded.has(m.id)) {
          candidates.push({ ...m, sub });
        }
      });
    });
  } else {
    // 다른 카테고리면 해당 카테고리에서 선택
    (MENUS_OTHERS[cat] || []).forEach(m => {
      if (!excluded.has(m.id)) candidates.push({ ...m, sub: null });
    });
  }
  
  return candidates;
}

// --------------------------
// 카테고리 랜덤 버튼 클릭
// --------------------------
function startCategoryRandom() {
  const container = $("#menu-chips");
  const originalHTML = container.innerHTML;
  container.innerHTML = "";
  container.style.display = "block";
  
  // 카테고리 후보 가져오기
  const catCandidates = getAllAvailableMenus();
  if (!catCandidates.length) {
    toast("추천할 카테고리가 없습니다");
    return;
  }
  
  // 카테고리 라벨 매핑
  const catLabels = {
    korean: "한식",
    chinese: "중식",
    japanese: "일식",
    southeast: "동남아",
    western: "서양식",
    etc: "기타",
  };
  
  // 슬롯머신 생성
  const catSlotMachine = document.createElement("div");
  catSlotMachine.className = "slot-machine";
  catSlotMachine.style.display = "flex";
  
  const catSlotItems = catCandidates.map(cat => catLabels[cat] || cat);
  let catCurrentIndex = 0;
  let catSpeed = 50;
  let catRounds = 1;
  let catRoundCount = 0;
  let catSlotInterval = null;
  let catLastSoundTime = 0;
  let catHasFinished = false;
  
  catSlotItems.forEach((catLabelText, idx) => {
    const item = document.createElement("div");
    item.className = "slot-item";
    item.textContent = catLabelText;
    item.dataset.index = idx;
    catSlotMachine.appendChild(item);
  });
  
  container.appendChild(catSlotMachine);
  const catSlotElements = Array.from(catSlotMachine.querySelectorAll(".slot-item"));
  
  playStartSound();
  
  const finalizeCatSpin = (forcedIndex = null) => {
    if (catHasFinished) return;
    catHasFinished = true;
    if (catSlotInterval) {
      clearTimeout(catSlotInterval);
      catSlotInterval = null;
  }
  setSkipHandler(null);
  updateGlobalInterval(null);
    playStopSound();
    
    catSlotElements.forEach(el => el.classList.remove("active", "next"));
    
    // 랜덤 인덱스 선택
    // forcedIndex가 있으면 (스킵 버튼) 그 인덱스 사용, 없으면 랜덤으로 선택
    let resolvedIndex;
    if (typeof forcedIndex === "number") {
      resolvedIndex = (forcedIndex % catSlotElements.length + catSlotElements.length) % catSlotElements.length;
  } else {
      // 룰렛이 자연스럽게 멈출 때 랜덤으로 선택
      // catCurrentIndex를 기반으로 하되, 추가 랜덤 요소를 더함
      const baseIndex = (catCurrentIndex % catSlotElements.length + catSlotElements.length) % catSlotElements.length;
      // 추가 랜덤 요소 (0~2칸 더 이동)
      const randomOffset = Math.floor(Math.random() * Math.min(3, catSlotElements.length));
      resolvedIndex = (baseIndex + randomOffset) % catSlotElements.length;
    }
    
    if (catSlotElements[resolvedIndex]) {
      catSlotElements[resolvedIndex].classList.add("active");
      catSlotElements[resolvedIndex].style.transform = "scale(1.1)";
      catSlotElements[resolvedIndex].style.transition = "transform 0.3s ease";
  }
  
    selectedCategoryFromRandom = catCandidates[resolvedIndex];
    
    // UI 업데이트
    currentCategory = selectedCategoryFromRandom;
    $("#category").value = selectedCategoryFromRandom;
    renderSubcategoryOptions();
    renderChips();
    
    // 카테고리 랜덤 버튼 숨기고 추천 버튼 활성화
    updateCategoryRandomButton();
    
    setTimeout(() => {
      container.innerHTML = originalHTML;
    renderChips();
    }, 1000);
  };
  
  setSkipHandler(() => finalizeCatSpin(catCurrentIndex));
  
  const spinCatSlot = () => {
    catSlotElements.forEach(el => {
      el.classList.remove("active", "next");
    });
    
    const currentEl = catSlotElements[catCurrentIndex];
    const nextEl = catSlotElements[(catCurrentIndex + 1) % catSlotElements.length];
    
    if (currentEl) {
      currentEl.classList.add("active");
      }
    if (nextEl) {
      nextEl.classList.add("next");
    }
    
    const now = Date.now();
    if ((now - catLastSoundTime) >= Math.max(catSpeed * 0.7, 30)) {
      const speedRatio = Math.min(1, Math.max(0, (catSpeed - 50) / 200));
      const frequency = 700 - (speedRatio * 350);
      const volume = 0.2 - (speedRatio * 0.1);
      const duration = 0.04 + (speedRatio * 0.04);
      playClickSound(frequency, volume, duration);
      catLastSoundTime = now;
    }
    
    if (catRoundCount >= catRounds) {
      catSpeed += 12;
      if (catSpeed > 200) {
        finalizeCatSpin();
    return;
  }
    }
    
    catCurrentIndex = (catCurrentIndex + 1) % catSlotElements.length;
    
    if (catCurrentIndex === 0) {
      catRoundCount++;
  }
  
    catSlotInterval = setTimeout(spinCatSlot, catSpeed);
    updateGlobalInterval(catSlotInterval);
};

  // 즉시 첫 번째 실행하여 첫 아이템이 보이게 함
  spinCatSlot();
  catSlotInterval = setTimeout(spinCatSlot, catSpeed);
  updateGlobalInterval(catSlotInterval);
  }

// --------------------------
// 게임 전략: 룰렛 (슬롯머신) - 메뉴 선택만
// --------------------------
function startSlotMachine(availableChips, btn, recoEl) {
  // menu-chips 영역에 게임 표시
  const container = $("#menu-chips");
  const originalHTML = container.innerHTML;
  container.innerHTML = "";
  container.style.display = "block";
  
  // 카테고리 랜덤이 선택되지 않았으면 현재 카테고리 사용
  const selectedCat = selectedCategoryFromRandom || currentCategory;
  
  // 선택된 카테고리에서 메뉴 선택
  const candidates = getAvailableMenusFromCategory(selectedCat);
  if (!candidates.length) {
    recoEl.textContent = "추천할 메뉴가 없습니다";
    btn.classList.remove("loading");
    btn.disabled = false;
    return;
  }
  
  const slotMachine = document.createElement("div");
  slotMachine.className = "slot-machine";
  slotMachine.style.display = "flex";
  
  playStartSound();
  
  const slotItems = candidates.map(m => m.label);
  let currentIndex = 0;
  let speed = 50;
  let rounds = 1;
  let roundCount = 0;
  let finalIndex = -1;
  let slotInterval = null;
  let lastSoundTime = 0;
  let hasFinished = false;
  
  slotItems.forEach((menu, idx) => {
    const item = document.createElement("div");
    item.className = "slot-item";
    item.textContent = menu;
    item.dataset.index = idx;
    slotMachine.appendChild(item);
  });
  
  container.appendChild(slotMachine);
  const slotElements = Array.from(slotMachine.querySelectorAll(".slot-item"));

  const finalizeSpin = (forcedIndex = null) => {
    if (hasFinished) return;
    hasFinished = true;
    if (slotInterval) {
      clearTimeout(slotInterval);
      slotInterval = null;
    }
    updateGlobalInterval(null);
    setSkipHandler(null);
    playStopSound();

    slotElements.forEach(el => el.classList.remove("active", "next"));

    const resolvedIndex = slotElements.length
      ? ((typeof forcedIndex === "number" ? forcedIndex : currentIndex) % slotElements.length + slotElements.length) % slotElements.length
      : 0;

    finalIndex = resolvedIndex;
    if (slotElements[finalIndex]) {
      slotElements[finalIndex].classList.add("active");
      slotElements[finalIndex].style.transform = "scale(1.1)";
      slotElements[finalIndex].style.transition = "transform 0.3s ease";
    }

    const finalMenu = slotItems[finalIndex] || "";
    highlightedMenu = finalMenu;
    autoExcludeMenu(finalMenu);
    
    // 추천 결과 저장
    const picked = candidates[finalIndex];
    if (picked) {
      lastRecoId = picked.id;
      lastRecoCat = selectedCat;
      lastRecoSub = picked.sub;
      
      // UI도 그 카테고리/서브카테고리로 맞춰 줌
      if (!selectedCategoryFromRandom) {
        currentCategory = selectedCat;
        $("#category").value = selectedCat;
        renderSubcategoryOptions();
      }
      if (selectedCat === "korean" && picked.sub) {
        currentSubcategory = picked.sub;
        $("#subcategory").value = picked.sub;
      }
    } else {
      // fallback: finalMenu로 찾기
      const found = candidates.find(m => m.label === finalMenu);
      if (found) {
        lastRecoId = found.id;
        lastRecoCat = selectedCat;
        lastRecoSub = found.sub;
        
        if (!selectedCategoryFromRandom) {
          currentCategory = selectedCat;
          $("#category").value = selectedCat;
          renderSubcategoryOptions();
        }
        if (selectedCat === "korean" && found.sub) {
          currentSubcategory = found.sub;
          $("#subcategory").value = found.sub;
        }
      }
    }
    
    recoEl.textContent = finalMenu ? `추천: ${finalMenu}` : "추천할 메뉴가 없습니다";
    recoEl.classList.add("show");

    setTimeout(() => {
      container.innerHTML = originalHTML;
      renderChips();
    }, 1000);

    btn.classList.remove("loading");
    btn.disabled = false;
    
    // 카테고리 랜덤 초기화
    selectedCategoryFromRandom = null;
    updateCategoryRandomButton();
  };

  setSkipHandler(() => finalizeSpin(currentIndex));
  
  const spinSlot = () => {
    slotElements.forEach(el => {
      el.classList.remove("active", "next");
    });
    
    const currentEl = slotElements[currentIndex];
    const nextEl = slotElements[(currentIndex + 1) % slotElements.length];
    
    if (currentEl) {
      currentEl.classList.add("active");
    }
    if (nextEl) {
      nextEl.classList.add("next");
    }
    
    const now = Date.now();
    if ((now - lastSoundTime) >= Math.max(speed * 0.7, 30)) {
      const speedRatio = Math.min(1, Math.max(0, (speed - 50) / 200));
      const frequency = 700 - (speedRatio * 350);
      const volume = 0.2 - (speedRatio * 0.1);
      const duration = 0.04 + (speedRatio * 0.04);
      playClickSound(frequency, volume, duration);
      lastSoundTime = now;
    }
    
    if (roundCount >= rounds) {
      speed += 12;
      if (speed > 200) {
        finalizeSpin(currentIndex);
        return;
      }
    }
    
    currentIndex = (currentIndex + 1) % slotElements.length;
    
    if (currentIndex === 0) {
      roundCount++;
    }
    
    slotInterval = setTimeout(spinSlot, speed);
    updateGlobalInterval(slotInterval);
  };
  
  // 즉시 첫 번째 실행하여 첫 아이템이 보이게 함
  spinSlot();
  slotInterval = setTimeout(spinSlot, speed);
  updateGlobalInterval(slotInterval);
}

// --------------------------
// 게임 전략: 인형 뽑기
// --------------------------
function startClawMachine(availableChips, btn, recoEl) {
  const container = $("#menu-chips");
  const originalHTML = container.innerHTML;
  container.innerHTML = "";

  // 카테고리 랜덤이 선택되지 않았으면 현재 카테고리 사용
  const selectedCat = selectedCategoryFromRandom || currentCategory;
  
  // 선택된 카테고리에서 메뉴 선택
  const candidates = getAvailableMenusFromCategory(selectedCat);
  if (!candidates.length) {
    recoEl.textContent = "추천할 메뉴가 없습니다";
    btn.classList.remove("loading");
    btn.disabled = false;
    return;
  }
  
  const menuPool = candidates.map(m => m.label);
  
  const clawArea = document.createElement("div");
  clawArea.className = "claw-area";
  
  const claw = document.createElement("div");
  claw.className = "claw";
  claw.id = "claw";
  clawArea.appendChild(claw);
  
  const capsulesContainer = document.createElement("div");
  capsulesContainer.className = "capsules-container";
  
  const capsuleCount = Math.min(30, Math.max(20, menuPool.length || 20));
  const colorClasses = ["color-0", "color-1", "color-2", "color-3"];
  for (let i = 0; i < capsuleCount; i += 1) {
    const capsule = document.createElement("div");
    const colorClass = colorClasses[Math.floor(Math.random() * colorClasses.length)];
    capsule.className = `capsule ${colorClass}`;
    const inner = document.createElement("div");
    inner.className = "capsule-text";
    inner.textContent = "?";
    capsule.appendChild(inner);
    const floatDelay = (Math.random() * 2).toFixed(2);
    const wobbleDelay = (Math.random() * 2).toFixed(2);
    const floatDuration = (2.4 + Math.random()).toFixed(2);
    const wobbleDuration = (2 + Math.random()).toFixed(2);
    capsule.style.animationDelay = `${floatDelay}s, ${wobbleDelay}s`;
    capsule.style.animationDuration = `${floatDuration}s, ${wobbleDuration}s`;
    capsulesContainer.appendChild(capsule);
  }
  
  clawArea.appendChild(capsulesContainer);
  const glassOverlay = document.createElement("div");
  glassOverlay.className = "claw-glass";
  clawArea.appendChild(glassOverlay);
  container.appendChild(clawArea);
  
  const resultBadge = document.createElement("div");
  resultBadge.className = "claw-result";
  resultBadge.textContent = "";
  resultBadge.style.display = "none";
  container.appendChild(resultBadge);

  let clawPosition = 50;
  let clawDirection = 1;
  const clawMoveInterval = setInterval(() => {
    clawPosition += clawDirection * 0.5;
    if (clawPosition > 90 || clawPosition < 10) {
      clawDirection *= -1;
    }
    claw.style.left = `${clawPosition}%`;
  }, 20);
  
  function findNearestCapsule() {
    const clawRect = claw.getBoundingClientRect();
    const clawCenter = clawRect.left + clawRect.width / 2;
    let bestDist = Infinity;
    const bestCapsules = [];
    capsulesContainer.querySelectorAll(".capsule").forEach(capsule => {
      const rect = capsule.getBoundingClientRect();
      const center = rect.left + rect.width / 2;
      const dist = Math.abs(center - clawCenter);
      if (dist < bestDist - 1) {
        bestDist = dist;
        bestCapsules.length = 0;
        bestCapsules.push(capsule);
      } else if (Math.abs(dist - bestDist) <= 2) {
        bestCapsules.push(capsule);
      }
    });
    if (!bestCapsules.length) return null;
    return bestCapsules[Math.floor(Math.random() * bestCapsules.length)];
  }

  function showReveal(menu) {
    const overlay = document.createElement("div");
    overlay.className = "capsule-reveal";
    overlay.innerHTML = `
      <div class="reveal-emoji">${getFoodEmoji(menu)}</div>
      <div class="reveal-name">${menu}</div>
    `;
    container.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add("show"));
    setTimeout(() => overlay.remove(), 1600);
  }

  btn.classList.remove("loading");
  btn.disabled = false;
  
  const originalOnclick = btn.onclick;
  btn.onclick = () => {
    clearInterval(clawMoveInterval);
    btn.classList.add("loading");
    btn.disabled = true;
    playStartSound();
    
    claw.classList.add("dropping");
    
    setTimeout(() => {
      const targetCapsule = findNearestCapsule()
        || capsulesContainer.querySelector(".capsule");
      const picked = candidates[Math.floor(Math.random() * candidates.length)];
      const selectedMenu = picked.label;

      if (targetCapsule) {
        targetCapsule.classList.add("picked");
        const textEl = targetCapsule.querySelector(".capsule-text");
        if (textEl) {
          textEl.textContent = getFoodEmoji(selectedMenu);
        }
      }
      playStopSound();
      resultBadge.textContent = `🎁 ${selectedMenu} 등장!`;
      resultBadge.style.display = "block";
      // showReveal 제거 - 흰색 방울 오버레이 제거
      
      setTimeout(() => {
        highlightedMenu = selectedMenu;
        autoExcludeMenu(selectedMenu);
        
        // 추천 결과 저장
        if (picked) {
          lastRecoId = picked.id;
          lastRecoCat = selectedCat;
          lastRecoSub = picked.sub;
          
          if (!selectedCategoryFromRandom) {
            currentCategory = selectedCat;
            $("#category").value = selectedCat;
            renderSubcategoryOptions();
          }
          if (selectedCat === "korean" && picked.sub) {
            currentSubcategory = picked.sub;
            $("#subcategory").value = picked.sub;
          }
        }
        
        recoEl.textContent = `🎁 당첨: ${selectedMenu}!`;
        recoEl.classList.add("show");
        
        container.innerHTML = originalHTML;
        renderChips();
        btn.classList.remove("loading");
        btn.disabled = false;
        btn.onclick = originalOnclick;
        
        // 카테고리 랜덤 초기화
        selectedCategoryFromRandom = null;
        updateCategoryRandomButton();
      }, 1500);
    }, 2000);
  };
}

// --------------------------
// 게임 전략: 스크래치 복권
// --------------------------
function startScratchCard(availableChips, btn, recoEl) {
  const container = $("#menu-chips");
  const originalHTML = container.innerHTML;
  container.innerHTML = "";
  
  // 카테고리 랜덤이 선택되지 않았으면 현재 카테고리 사용
  const selectedCat = selectedCategoryFromRandom || currentCategory;
  
  // 선택된 카테고리에서 메뉴 선택
  const candidates = getAvailableMenusFromCategory(selectedCat);
  if (!candidates.length) {
    recoEl.textContent = "추천할 메뉴가 없습니다";
    btn.classList.remove("loading");
    btn.disabled = false;
    return;
  }
  
  const scratchArea = document.createElement("div");
  scratchArea.className = "scratch-area";
  
  const canvas = document.createElement("canvas");
  canvas.id = "scratch-canvas";
  
  const resultDiv = document.createElement("div");
  resultDiv.className = "scratch-result";
  const emojiDiv = document.createElement("div");
  emojiDiv.className = "result-emoji";
  const textDiv = document.createElement("div");
  textDiv.className = "result-text";
  resultDiv.appendChild(emojiDiv);
  resultDiv.appendChild(textDiv);
  
  scratchArea.appendChild(canvas);
  scratchArea.appendChild(resultDiv);
  container.appendChild(scratchArea);
  
  // 랜덤 메뉴 선택
  const picked = candidates[Math.floor(Math.random() * candidates.length)];
  const selectedMenu = picked.label;
  emojiDiv.textContent = getFoodEmoji(selectedMenu);
  textDiv.textContent = selectedMenu;
  
  // 캔버스 설정
  const rect = scratchArea.getBoundingClientRect();
  canvas.width = rect.width;
  canvas.height = rect.height;
  
  const ctx = canvas.getContext("2d");
  
  // 은색 레이어 그리기
  ctx.fillStyle = "#c0c0c0";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#888";
  ctx.font = "bold 36px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("긁어보세요!", canvas.width / 2, canvas.height / 2);
  
  let isScratching = false;
  let hasRevealed = false; // 결과 공개 여부 플래그
  const revealThreshold = 0.3; // 30% 긁으면 공개
  
  function scratch(e) {
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX || e.touches[0].clientX) - rect.left;
    const y = (e.clientY || e.touches[0].clientY) - rect.top;
    
    // 원형으로 긁기
    ctx.globalCompositeOperation = "destination-out";
    ctx.beginPath();
    ctx.arc(x, y, 40, 0, Math.PI * 2);
    ctx.fill();
    
    // 긁힌 픽셀 계산
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    let transparent = 0;
    for (let i = 3; i < imageData.data.length; i += 4) {
      if (imageData.data[i] === 0) transparent++;
    }
    const scratchedPixels = transparent / (imageData.data.length / 4);
    
    // 30% 이상 긁히면 결과 공개 (한 번만 실행)
    if (scratchedPixels >= revealThreshold && !hasRevealed) {
      hasRevealed = true; // 플래그 설정하여 중복 실행 방지
      playStopSound(); // 인형뽑기와 같은 당첨 음악
      canvas.style.opacity = "0";
      canvas.style.transition = "opacity 0.5s";
      
      setTimeout(() => {
        highlightedMenu = selectedMenu;
        autoExcludeMenu(selectedMenu);
        
        // 추천 결과 저장
        if (picked) {
          lastRecoId = picked.id;
          lastRecoCat = selectedCat;
          lastRecoSub = picked.sub;
          
          if (!selectedCategoryFromRandom) {
            currentCategory = selectedCat;
            $("#category").value = selectedCat;
            renderSubcategoryOptions();
          }
          if (selectedCat === "korean" && picked.sub) {
            currentSubcategory = picked.sub;
            $("#subcategory").value = picked.sub;
          }
        }
        
        recoEl.textContent = `🎫 당첨: ${selectedMenu}!`;
        recoEl.classList.add("show");
        
        container.innerHTML = originalHTML;
        renderChips();
        btn.classList.remove("loading");
        btn.disabled = false;
        
        // 카테고리 랜덤 초기화
        selectedCategoryFromRandom = null;
        updateCategoryRandomButton();
      }, 3000); // 결과를 더 오래 보이도록 3초로 변경
    }
  }
  
  canvas.addEventListener("mousedown", (e) => {
    isScratching = true;
    scratch(e);
  });
  
  canvas.addEventListener("mousemove", (e) => {
    if (isScratching) scratch(e);
  });
  
  canvas.addEventListener("mouseup", () => {
    isScratching = false;
  });
  
  canvas.addEventListener("touchstart", (e) => {
    e.preventDefault();
    isScratching = true;
    scratch(e);
  });
  
  canvas.addEventListener("touchmove", (e) => {
    e.preventDefault();
    if (isScratching) scratch(e);
  });
  
  canvas.addEventListener("touchend", () => {
    isScratching = false;
  });
  
  btn.classList.remove("loading");
  btn.disabled = false;
}

// 음식 이모지 매핑 함수
function getFoodEmoji(name) {
  const emojiMap = {
    "김치찌개": "🍲", "된장찌개": "🍲", "순두부찌개": "🍲", "부대찌개": "🍲",
    "청국장": "🍲", "갈비탕": "🍲", "설렁탕": "🍲", "육개장": "🍲",
    "삼계탕": "🍲", "감자탕": "🍲", "돼지국밥": "🍲", "소고기국밥": "🍲",
    "순대국밥": "🍲", "콩나물국밥": "🍲", "얼큰이국밥": "🍲", "내장국밥": "🍲",
    "굴국밥": "🍲", "선지해장국": "🍲",
    "제육볶음": "🥩", "오징어볶음": "🦑", "불고기": "🥩", "삼겹살": "🥓",
    "닭갈비": "🍗", "장어구이": "🐟",
    "비빔밥": "🍚", "돌솥비빔밥": "🍚", "육회비빔밥": "🍚", "뚝배기불고기": "🍲",
    "곱창덮밥": "🍚", "장조림덮밥": "🍚",
    "칼국수": "🍜", "잔치국수": "🍜", "냉면": "🍜", "비빔냉면": "🍜", "콩국수": "🍜",
    "김밥": "🍙", "찜닭": "🍗", "족발": "🍖", "보쌈": "🥬",
    "해물파전": "🥞", "물회": "🍲", "잡채": "🥢",
  };
  return emojiMap[name] || "🍽️";
}

// 자동 제외
function autoExcludeMenu(label) {
  if (!label) return;
  const menuObj = getVisibleMenuList().find(m => m.label === label);
  if (menuObj && !autoExcludedMenuIds.has(menuObj.id)) {
    excluded.add(menuObj.id);
    autoExcludedMenuIds.add(menuObj.id);
  }
}

// 초기화 버튼
$("#btn-reset-auto")?.addEventListener("click", () => {
  autoExcludedMenuIds.clear();
  excluded.clear();
  selectedCategoryFromRandom = null;
  renderChips();
  updateCategoryRandomButton();
  toast("자동 제외 초기화");
});

// 게임 전략 등록
gameStrategies.roulette = withLogging("roulette", (chips, btn, reco) => startSlotMachine(chips, btn, reco));
gameStrategies.claw = withLogging("claw", (chips, btn, reco) => startClawMachine(chips, btn, reco));
gameStrategies.scratch = withLogging("scratch", (chips, btn, reco) => startScratchCard(chips, btn, reco));

// --------------------------
// 추천 받기
// --------------------------
$("#btn-reco").onclick = async () => {
  const btn = $("#btn-reco");
  const recoEl = $("#reco");
  
  btn.classList.add("loading");
  btn.disabled = true;
  recoEl.textContent = "";
  recoEl.classList.remove("show", "pulse");
  setSkipHandler(null);
  
  // 추천 방식에 따라 다른 함수 호출
  const modeSelect = $("#recommendation-mode");
  const mode = modeSelect?.value || recommendationMode;
  recommendationMode = mode;
  if (mode === 'roulette') {
    primeSkipButton();
  } else {
    pendingSkipRequest = false;
  }
  
  const runner = gameStrategies[mode] || gameStrategies.roulette;
  runner?.(null, btn, recoEl); // availableChips 대신 null 전달 (카테고리 전체에서 선택)
};

// 추천 방식 변경 시
$("#recommendation-mode")?.addEventListener("change", async (e) => {
  recommendationMode = e.target.value;
  
  const btn = $("#btn-reco");
  const recoEl = $("#reco");
  if (btn) {
    btn.classList.remove("loading");
    btn.disabled = false;
  }
  if (recoEl) {
    recoEl.textContent = "";
    recoEl.classList.remove("show", "pulse");
  }
  setSkipHandler(null);
  updateGlobalInterval(null);
  
  renderChips();
});

// --------------------------
// 위치 검색 (/api/places 호출)
// --------------------------
$("#btn-search").onclick = async () => {
  if (!navigator.geolocation) return alert("Geolocation 미지원");

  if (!lastRecoId || !lastRecoCat) {
    return alert("먼저 추천을 받아주세요.");
  }

  let radius = Number($("#radius").value || 2000);
  // 반경 제한 제거
  const { label } = findLabelAndMetaById(lastRecoId) || {};
  if (!label) {
    return alert("추천 메뉴 정보를 찾을 수 없습니다.");
  }

  $("#list").innerHTML = '<li class="muted">위치 확인 중...</li>';
  const geoTimeoutMs = 8000;
  const geoTimer = setTimeout(() => {
    $("#list").innerHTML = '<li class="muted">위치 확인이 지연됩니다. 브라우저 권한을 확인하세요.</li>';
    toast("위치 확인 지연");
  }, geoTimeoutMs);

  navigator.geolocation.getCurrentPosition(
    async (pos) => {
      clearTimeout(geoTimer);
      const { latitude: y, longitude: x } = pos.coords;
      
      // 좌표 보정 적용
      const corrected = correctCoordinate(y, x);
      lastGeo = { x: corrected.lng, y: corrected.lat };

      const params = new URLSearchParams({
        menu: label,
        cat: lastRecoCat,
        menuId: lastRecoId,
      });
      if (lastRecoCat === "korean" && lastRecoSub) {
        params.append("sub", lastRecoSub);
      }
      // 보정된 좌표를 API에 전달
      params.append("x", String(corrected.lng));
      params.append("y", String(corrected.lat));
      params.append("radius", String(radius));

      const url = `/api/places?${params.toString()}`;

      try {
        const res = await fetch(url);
        const data = await res.json();
        lastPlaces = Array.isArray(data?.places) ? data.places : [];
        applySortFilter();
        toast("검색 완료");
        pushRecent(label);
        renderRecent();
      } catch (e) {
        console.error(e);
        $("#list").innerHTML = '<li class="muted">검색 실패</li>';
        toast("검색 실패");
      }
    },
    (err) => {
      clearTimeout(geoTimer);
      const msg = err?.code === 1 ? "위치 권한이 거부되었습니다"
        : err?.code === 2 ? "기기 위치를 가져올 수 없습니다"
        : err?.code === 3 ? "위치 요청이 시간 초과되었습니다"
        : "위치 권한 필요 또는 실패";
      $("#list").innerHTML = `<li class="muted">${msg}</li>`;
      toast(msg);
    },
    { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 }
  );
};

// --------------------------
// 근처 식당 리스트 
// --------------------------
function renderList(places) {
  const ul = $("#list");
  ul.innerHTML = "";
  if (!places.length) {
    ul.innerHTML = '<li class="muted">근처 결과가 없어요</li>';
    return;
  }
  places.forEach(p => {
    const li = document.createElement("li");
    const link = `https://map.kakao.com/link/search/${encodeURIComponent(p.name || "")}`;
    const star = favorites.has(p.name) ? "★" : "☆";
    li.innerHTML = `
      <div>
        <strong>${p.name}</strong> - ${p.address ?? ""} (${p.distance ?? "?"}m)
      </div>
      <div style="display:flex;gap:8px;align-items:center">
        <button class="preview" data-name="${encodeURIComponent(p.name || "")}">미리보기</button>
        <button class="map" data-link="${link}">지도</button>
        <button class="route kakao" data-name="${encodeURIComponent(p.name || "")}" data-x="${p.lng ?? ""}" data-y="${p.lat ?? ""}">길찾기</button>
        <button class="route more" data-name="${encodeURIComponent(p.name || "")}" data-address="${encodeURIComponent(p.address || "")}" data-tel="${encodeURIComponent(p.tel || "")}" data-x="${p.lng ?? ""}" data-y="${p.lat ?? ""}">⋯</button>
        <button class="fav" data-name="${p.name}">${star}</button>
      </div>`;
    ul.appendChild(li);
    li.querySelector(".fav").onclick = (e) => toggleFavorite(e.currentTarget.dataset.name);
    li.querySelector(".preview").onclick = (e) => openPreview(decodeURIComponent(e.currentTarget.dataset.name));
    li.querySelector(".map").onclick = (e) => window.open(e.currentTarget.dataset.link, "_blank", "rel=noreferrer");
    li.querySelector(".route.kakao").onclick = (e) => openRoute("kakao", decodeURIComponent(e.currentTarget.dataset.name), e.currentTarget.dataset.x, e.currentTarget.dataset.y);
    li.querySelector(".route.more").onclick = (e) => {
      const name = decodeURIComponent(e.currentTarget.dataset.name);
      const address = decodeURIComponent(e.currentTarget.dataset.address);
      const tel = decodeURIComponent(e.currentTarget.dataset.tel);
      const x = e.currentTarget.dataset.x;
      const y = e.currentTarget.dataset.y;
      openPlaceMenu(name, address, tel, x, y);
    };
  });
}

// --------------------------
// 정렬/필터
// --------------------------
$("#sort")?.addEventListener("change", (e) => { currentSort = e.target.value; applySortFilter(); });
$("#only-fav")?.addEventListener("change", (e) => { onlyFav = e.target.checked; applySortFilter(); });

function applySortFilter() {
  let arr = [...lastPlaces];
  if (onlyFav) arr = arr.filter(p => favorites.has(p.name));
  if (currentSort === "distance") arr.sort((a,b) => (a.distance ?? Infinity) - (b.distance ?? Infinity));
  else if (currentSort === "name") arr.sort((a,b) => (a.name||"").localeCompare(b.name||""));
  renderList(arr);
  const c = $("#count"); if (c) c.textContent = arr.length ? `${arr.length}건` : "";
}

// --------------------------
// 즐겨찾기
// --------------------------
function toggleFavorite(name) {
  if (!name) return;
  if (favorites.has(name)) favorites.delete(name); else favorites.add(name);
  localStorage.setItem(FAV_KEY, JSON.stringify([...favorites]));
  applySortFilter();
}

// --------------------------
// 토스트
// --------------------------
function toast(msg, ms = 1800) {
  const t = document.getElementById("toast");
  if (!t) return;
  t.textContent = msg;
  t.style.display = "block";
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => t.style.display = "none", ms);
}

// --------------------------
// 지도 미리보기 모달
// --------------------------
const modal = $("#modal");
const modalBg = $("#modal-bg");
const modalTitle = $("#modal-title");
const mapFrame = $("#map-frame");
$("#modal-close")?.addEventListener("click", closePreview);
modalBg?.addEventListener("click", closePreview);
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closePreview(); });

function openPreview(name) {
  if (!name) return;
  modalTitle.textContent = name;
  const url = `https://map.kakao.com/link/search/${encodeURIComponent(name)}`;
  if (mapFrame) mapFrame.src = url;
  if (modal) modal.style.display = "flex";
  if (modalBg) modalBg.style.display = "block";
}
function closePreview() {
  if (modal) modal.style.display = "none";
  if (modalBg) modalBg.style.display = "none";
  if (mapFrame) mapFrame.src = "";
}

// --------------------------
// 최근 검색
// --------------------------
function pushRecent(menuLabel) {
  const next = [{ label: menuLabel, t: Date.now() }, ...recentSearches.filter(r => r.label !== menuLabel)];
  recentSearches = next.slice(0, 5);
  localStorage.setItem(RECENT_KEY, JSON.stringify(recentSearches));
}
function renderRecent() {
  const wrap = $("#recent");
  if (!wrap) return;
  wrap.innerHTML = "";
  if (!recentSearches.length) { wrap.style.display = "none"; return; }
  wrap.style.display = "flex";
  recentSearches.forEach(r => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "chip";
    b.textContent = r.label;
    b.onclick = () => quickSearch(r.label);
    wrap.appendChild(b);
  });
}
async function quickSearch(menuLabel) {
  if (!navigator.geolocation) return alert("Geolocation 미지원");
  
  // 메뉴 레이블로부터 메뉴 정보 찾기
  const menuInfo = findIdAndMetaByLabel(menuLabel);
  if (!menuInfo) {
    return alert(`메뉴 "${menuLabel}"을 찾을 수 없습니다.`);
  }
  
  // 검색에 필요한 정보 설정
  lastRecoId = menuInfo.id;
  lastRecoCat = menuInfo.cat;
  lastRecoSub = menuInfo.sub || null;
  
  // UI 업데이트
  $("#reco").textContent = `추천: ${menuLabel}`;
  currentCategory = menuInfo.cat;
  $("#category").value = menuInfo.cat;
  
  if (menuInfo.cat === "korean" && menuInfo.sub) {
    currentSubcategory = menuInfo.sub;
    $("#subcategory").value = menuInfo.sub;
    renderSubcategoryOptions();
  } else {
    renderSubcategoryOptions();
  }
  
  // 검색 실행
  $("#btn-search").click();
}
renderRecent();

// 최근 비우기
$("#recent-clear")?.addEventListener("click", () => {
  recentSearches = [];
  localStorage.setItem(RECENT_KEY, JSON.stringify(recentSearches));
  renderRecent();
  toast("최근 검색을 비웠습니다");
});

// --------------------------
// 길찾기
// --------------------------
function openRoute(provider, name, x, y) {
  // 1. 내 위치 정보(lastGeo)가 있는지 확인
  if (!lastGeo) {
    // 내 위치가 없으면 브라우저에서 위치부터 가져옴
    if (!navigator.geolocation) {
      alert("위치 정보를 사용할 수 없습니다.");
      window.open(`https://map.kakao.com/link/search/${encodeURIComponent(name)}`, "_blank");
      return;
    }
    
    // 위치 가져오기 시도 (토스트 메시지 표시)
    toast("내 위치 확인 중...");
    
    navigator.geolocation.getCurrentPosition((pos) => {
      const { latitude, longitude } = pos.coords;
      
      // 좌표 보정 적용
      const corrected = correctCoordinate(latitude, longitude);
      lastGeo = { x: corrected.lng, y: corrected.lat }; // 위치 저장
      
      // 위치 찾았으니 다시 함수 실행 (재귀 호출)
      openRoute(provider, name, x, y);
    }, () => {
      alert("내 위치를 가져올 수 없습니다. 권한을 확인해주세요.");
      // 위치 실패 시 그냥 도착지만 검색
      window.open(`https://map.kakao.com/link/search/${encodeURIComponent(name)}`, "_blank");
    }, { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 });
    return;
  }

  // 2. 좌표 준비 (순서 중요: y=위도, x=경도)
  const startLat = lastGeo.y; // 내 위치 위도
  const startLng = lastGeo.x; // 내 위치 경도
  const endLat = y;           // 도착지 위도
  const endLng = x;           // 도착지 경도
  
  // 3. 카카오맵 길찾기 URL 생성 (권장 방식)
  // 형식: https://map.kakao.com/link/from/출발지명,위도,경도/to/도착지명,위도,경도
  let url = "";
  
  if (provider === "kakao") {
    if (startLat && startLng && endLat && endLng) {
      // 출발지(내 위치) -> 도착지(식당) 경로 바로 열기
      url = `https://map.kakao.com/link/from/내 위치,${startLat},${startLng}/to/${encodeURIComponent(name)},${endLat},${endLng}`;
    } else {
      // 좌표가 하나라도 없으면 그냥 검색 결과로 이동
      url = `https://map.kakao.com/link/search/${encodeURIComponent(name)}`;
    }
  }
  
  // 4. 새 창으로 열기
  window.open(url, "_blank");
}
function openPlaceMenu(name, address, tel, x, y) {
  const menuItems = [];
  
  // 전화번호 표시 (전화번호가 있을 때만)
  if (tel && tel.trim()) {
    menuItems.push(`<li style="padding: 14px 16px; color: #333;">📞 ${tel}</li>`);
  }
  
  // 주소 복사
  if (address && address.trim()) {
    menuItems.push(`<li><a href='#' onclick="navigator.clipboard.writeText('${address.replace(/'/g, "\\'")}'); alert('주소가 복사되었습니다.'); return false;" style="text-decoration:none;color:#333;cursor:pointer;display:block;padding:14px 16px;">📋 주소 복사</a></li>`);
  }
  
  // 카카오맵에서 보기
  const mapLink = `https://map.kakao.com/link/search/${encodeURIComponent(name)}`;
  menuItems.push(`<li><a href='${mapLink}' target='_blank' style="text-decoration:none;color:#333;display:block;padding:14px 16px;">🗺️ 카카오맵에서 보기</a></li>`);
  
  if (menuItems.length === 0) {
    toast("사용 가능한 기능이 없습니다");
    return;
  }
  
  const menu = window.open("", "_blank");
  if (menu) {
    menu.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>${name}</title>
        <style>
          body { font-family: system-ui, -apple-system, sans-serif; margin: 0; padding: 16px; background: #f5f5f5; }
          ul { list-style: none; padding: 0; margin: 0; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
          li { border-bottom: 1px solid #eee; }
          li:last-child { border-bottom: none; }
          a { transition: background 0.2s; }
          a:hover { background: #f0f0f0; }
          .title { padding: 12px 16px; background: #fee500; font-weight: bold; color: #000; }
        </style>
      </head>
      <body>
        <div class="title">${name}</div>
        <ul>${menuItems.join('')}</ul>
      </body>
      </html>
    `);
  }
}

// --------------------------
//  id → label/meta 찾기
// --------------------------
function findLabelAndMetaById(id) {
  if (!id) return null;

  // 한식
  for (const [sub, arr] of Object.entries(MENUS_KOREAN || {})) {
    const f = arr.find(m => m.id === id);
    if (f) return { label: f.label, cat: "korean", sub };
  }
  // 나머지
  for (const [cat, arr] of Object.entries(MENUS_OTHERS || {})) {
    const f = arr.find(m => m.id === id);
    if (f) return { label: f.label, cat, sub: null };
  }
  return null;
}

function findIdAndMetaByLabel(label) {
  if (!label) return null;

  // 한식
  for (const [sub, arr] of Object.entries(MENUS_KOREAN || {})) {
    const f = arr.find(m => m.label === label);
    if (f) return { id: f.id, label: f.label, cat: "korean", sub };
  }
  // 나머지
  for (const [cat, arr] of Object.entries(MENUS_OTHERS || {})) {
    const f = arr.find(m => m.label === label);
    if (f) return { id: f.id, label: f.label, cat, sub: null };
  }
  return null;
}

// --------------------------
// 카테고리 변경 핸들러
// --------------------------
$("#category").addEventListener("change", (e) => {
  currentCategory = e.target.value;
  selectedCategoryFromRandom = null; // 카테고리 변경 시 랜덤 결과 초기화
  renderSubcategoryOptions();
  renderChips();
  highlightedMenu = null;
  $("#reco").textContent = "";
  updateCategoryRandomButton();
});

$("#subcategory").addEventListener("change", (e) => {
  currentSubcategory = e.target.value;
  renderChips();
  highlightedMenu = null;
  $("#reco").textContent = "";
});

// 카테고리 랜덤 버튼 클릭 핸들러
$("#btn-category-random")?.addEventListener("click", () => {
  startCategoryRandom();
});

$("#btn-category-random-korean")?.addEventListener("click", () => {
  startCategoryRandom();
});

// 스킵 버튼 클릭 핸들러
skipButton?.addEventListener("click", () => {
  if (skipButton.disabled) return;
  if (activeSkipHandler) {
    skipButton.disabled = true;
    activeSkipHandler();
  } else {
    pendingSkipRequest = true;
  }
});

// --------------------------
// 시작
// --------------------------
loadMenus();
