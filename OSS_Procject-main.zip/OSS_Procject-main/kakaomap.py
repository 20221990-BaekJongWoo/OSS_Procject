from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
from prettytable import PrettyTable

# 野껓옙占쎄퉳占쎈막 占쎌벉占쎈뻼 �뵳�딅뮞占쎈뱜
foods = [
    # �뤃占쏙옙�땾/獄쏉옙/��뚣끇�봺 占쎈쾻 筌롫뗄�뵥 占쎌뒄�뵳占�
    "占쎌뵠占쏙옙占쏙옙�뻼 �뤃占쏙옙�땾 占쎌뒄�뵳占�", "占쎌뵥占쎈즲占쎈뻼 �뜮袁ⓥ봺占쎈튊占쎈빍", "餓λ쵎猷놅옙�뻼 占쎈툡占쎌뵬占쎈늄", "�뜎醫롫뮞�뜎醫롫뮞",
    "筌롫벡�뻻燁삼옙 �겫占썹뵳�됱굢", "占쏙옙占썼굜遺얠뵬占쎌뵠占쎈뮞", "占쎌뵥占쎈즲 ��뚣끇�봺", "占쏙옙占쏙옙�뵠 ��뚣끇�봺",
    "�눧�똻沅쀧㎉占�", "占쎈막占쎌뵬沃섓옙", "��놂옙獄쏉옙", "占쏙옙占썼굜占�", "占쎈솋占쎌뵬占쎈젂", "占쎄뭉占쏙옙占썹몴���彛�",
    "�뇡�슢�뵬筌욑옙 占쎈뭼占쎈릭占쎈뮞�굜占�",

    # �뜮占�/占쎄퉺占쎈굡占쎌맄燁삼옙/揶쏉옙甕곗눘�뒲 占쎈뻼占쎄텢
    "占쎈솁占쎈빍占쎈빍", "占쎄쾿占쎌쟿占쎈읂", "�뇡�슢�쑕燁삼옙 占쎈탣占쎌쟿占쎌뵠占쎈뱜", "占쎈돗占쏙옙占� 占쎄퉺占쎈굡占쎌맄燁삼옙",

    # 疫꿸퀬占쏙옙
    "占쎈퓠域밸챷�뵥占쎈연"
]



# 占쎌맅 占쎄쾿嚥∽옙 �뇡�슢�뵬占쎌뒭占쏙옙占� 占쎈였疫뀐옙
driver = webdriver.Chrome()
driver.get("https://map.kakao.com/")
time.sleep(2)

results = []

print("\n占쎌쐨占� 占쏙옙占쏙옙�읈 筌욑옙占쎈열 占쎌벉占쎈뻼占쎌젎 野껓옙占쎄퉳 餓ο옙...\n")

for food in foods:
    # 野껓옙占쎄퉳筌∽옙 筌≪뼐由� 獄쏉옙 野껓옙占쎄퉳占쎈선 占쎌뿯占쎌젾
    search_box = driver.find_element(By.ID, "search.keyword.query")
    search_box.clear()
    search_box.send_keys(f"占쏙옙占쏙옙�읈 {food}")
    search_box.send_keys(Keys.RETURN)
    time.sleep(2)

    # 野껓옙占쎄퉳 野껉퀗�궢 占쎌넇占쎌뵥
    try:
        driver.find_element(By.CSS_SELECTOR, ".placelist .PlaceItem")
        exists = "占쎌뿳占쎌벉"
    except:
        exists = "占쎈씨占쎌벉"

    results.append((food, exists))
    print(f"{food}: {exists}")

# 占쎌맅 占쎈ご 占쎌굨占쎄묶嚥∽옙 野껉퀗�궢 �빊�뮆�젾
print("\n 野껓옙占쎄퉳 野껉퀗�궢 占쎌뒄占쎈튋\n")
table = PrettyTable(["占쎌벉占쎈뻼筌륅옙", "占쏙옙占쏙옙�읈 占쎄땀 占쎌벉占쎈뻼占쎌젎 占쎈연�겫占�"])
for food, exists in results:
    status = "占쎌맅 占쎌뿳占쎌벉" if exists == "占쎌뿳占쎌벉" else "占쎌벉 占쎈씨占쎌벉"
    table.add_row([food, status])

print(table)

# 占쎌맅 占쎄쾿嚥∽옙 �넫�굝利�
driver.quit()
