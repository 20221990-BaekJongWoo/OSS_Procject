from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
from prettytable import PrettyTable

# 테스트할 음식점 목록
foods = [
    # 찌개/탕/국밥류 관련 메뉴
    "김치찌개 전문 음식점", "된장찌개 맛집", "순두부찌개 맛집", "부대찌개",
    "갈비탕 맛집", "설렁탕 맛집", "감자탕 맛집", "곰탕 맛집",
    "돼지국밥", "순대국밥", "콩나물국밥", "해장국", "뼈해장국", "선지해장국",
    "닭볶음탕 맛집",

    # 볶음/구이류/안주류 관련
    "제육볶음", "불고기 맛집", "삼겹살 맛집", "갈비 맛집",

    # 기타
    "비빔밥 맛집"
]




# 크롬 드라이버 실행 및 카카오맵 접속
driver = webdriver.Chrome()
driver.get("https://map.kakao.com/")
time.sleep(2)

results = []

print("\n각 음식점이 대전에 있는지 확인 중...\n")

for food in foods:
    # 음식점명으로 검색하여 해당 음식점이 있는지 확인
    search_box = driver.find_element(By.ID, "search.keyword.query")
    search_box.clear()
    search_box.send_keys(f"대전 {food}")
    search_box.send_keys(Keys.RETURN)
    time.sleep(2)

    # 음식점 검색 결과 존재 여부
    try:
        driver.find_element(By.CSS_SELECTOR, ".placelist .PlaceItem")
        exists = "존재"
    except:
        exists = "없음"

    results.append((food, exists))
    print(f"{food}: {exists}")

# 크롬 창 닫기 전에 결과 출력
print("\n 음식점 검색 결과 요약\n")
table = PrettyTable(["음식점명", "대전에 있는지 여부"])
for food, exists in results:
    status = "있음" if exists == "존재" else "없음"
    table.add_row([food, status])

print(table)

# 크롬 드라이버 종료
driver.quit()
