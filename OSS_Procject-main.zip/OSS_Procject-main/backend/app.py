# -*- coding: utf-8 -*-
from flask import Flask, request, jsonify
from dotenv import load_dotenv
import os, time, math, json, requests, random
from typing import Dict, Any, List

# -------------------------
# 설정/초기화
# -------------------------
load_dotenv()
KAKAO_KEY = os.getenv("KAKAO_REST_KEY")
if not KAKAO_KEY:
    print("경고 메시지: KAKAO_REST_KEY가 .env 파일에 설정되지 않았습니다.")
    print("다음 backend_tmp/.env 파일을 생성하고 다음을 추가하세요:")
    print("   KAKAO_REST_KEY=여기에_받은_REST_API_키_입력")
    print("더 자세한 방법: 카카오_API_키_받는_방법.md")
    # 서버는 실행되지만 API 키 없을 시 에러 발생

app = Flask(__name__)

# 메뉴 인덱스 로드 (aliases 활용하여)
with open(os.path.join(os.path.dirname(__file__), "menu_index.json"), "r", encoding="utf-8") as f:
    DATA = json.load(f)
MENU_INDEX: Dict[str, Dict[str, List[str]]] = DATA.get("menu_index", {})

# 카테고리명 매핑 (한글 -> 영문)
CATEGORY_MAP = {
    "한식": "korean",
    "중식": "chinese",
    "일식": "japanese",
    "서양식": "western",
    "동남아": "southeast",
    "기타": "etc",
}
# 역매핑 (영문 -> 한글)
CATEGORY_LABELS = {v: k for k, v in CATEGORY_MAP.items()}

# 한식 세부 카테고리 매핑
KOREAN_SUBCATEGORY_LABELS = {
    "korean_stew": "찌개류",
    "korean_soup": "탕류",
    "korean_rice_soup": "국밥류",
    "korean_stir_fry": "볶음류",
    "korean_grill": "구이류",
    "korean_bibimbap": "비빔밥/돌솥밥",
    "korean_noodle": "면류",
    "korean_rice": "밥류",
    "korean_pancake": "전/부침류",
    "korean_raw_fish": "회/생선류",
    "korean_other": "기타"
}

# 문자열 정규화(공백 제거 + 소문자)
def norm(s: str) -> str:
    return (s or "").strip().lower().replace(" ", "")

# -------------------------
# 좌표 보정
# -------------------------
# 잘못된 좌표와 올바른 좌표의 차이(오프셋) 계산
# 잘못된 좌표: (36.4511232, 127.4380288)
# 올바른 좌표: (36.454021, 127.422518)
COORD_OFFSET_LAT = 36.454021 - 36.4511232  # 위도 오프셋: 0.0028978
COORD_OFFSET_LNG = 127.422518 - 127.4380288  # 경도 오프셋: -0.0155108

def correct_coordinate(lat: float, lng: float) -> tuple[float, float]:
    """
    좌표 보정: 계산된 위치(잘못된 위치)에서 오프셋을 적용하여 올바른 좌표로 변환
    위도는 +0.0028978, 경도는 -0.0155108을 더함
    """
    corrected_lat = lat + COORD_OFFSET_LAT
    corrected_lng = lng + COORD_OFFSET_LNG
    return (corrected_lat, corrected_lng)

# 브랜드 이름에서 주요 키워드 추출 (예: "맥도날드 대전역점" -> "맥도날드")
def extract_brand_keyword(brand: str) -> str:
    """브랜드 이름에서 주요 키워드 추출"""
    # 일반적인 브랜드 패턴: "브랜드명 지점명" 또는 "브랜드명"
    # 공백으로 분리하고 첫 번째 단어를 주요 키워드로 사용
    parts = brand.strip().split()
    if parts:
        # 첫 번째 단어가 주요 브랜드명일 가능성이 높음
        return norm(parts[0])
    return norm(brand)

# -------------------------
# 캐시 (메모리 기반)
# -------------------------
TTL = 600  # 10분
GEO_CACHE: Dict[str, Dict[str, Any]] = {}

def geokey(lng: float, lat: float, radius: int) -> str:
    # 좌표 기반 캐시 키: 좌표를 3자리수(약 100m) + 반경
    return f"{round(lng,3)}:{round(lat,3)}:{radius}"

def save_cache(store: Dict, key: str, payload: Dict[str, Any]):
    store[key] = {"expires": time.time()+TTL, **payload}

def load_cache(store: Dict, key: str):
    v = store.get(key)
    if not v:
        return None
    if v["expires"] < time.time():
        store.pop(key, None)
        return None
    return v

# -------------------------
# Kakao Local REST API
# -------------------------
KAKAO_LOCAL_CATEGORY = "https://dapi.kakao.com/v2/local/search/category.json"
KAKAO_LOCAL_KEYWORD = "https://dapi.kakao.com/v2/local/search/keyword.json"
KAKAO_LOCAL_COORD2ADDRESS = "https://dapi.kakao.com/v2/local/geo/coord2address.json"

def get_headers():
    """API 헤더 생성 (키가 없으면 None 반환)"""
    if not KAKAO_KEY:
        return None
    return {"Authorization": f"KakaoAK {KAKAO_KEY}"}

def kakao_category_fd6(lng: float, lat: float, radius: int, page: int = 1, size: int = 15):
    # API 키 확인
    headers = get_headers()
    if not headers:
        raise Exception("KAKAO_REST_KEY가 설정되지 않았습니다. backend_tmp/.env 파일에 API 키를 설정하세요.")
    
    # x=경도(lng), y=위도(lat)
    params = {
        "category_group_code": "FD6",
        # 카카오맵 API 문서에 따르면 x: lng, y: lat 순서
        "x": lng,   # 경도(longitude)
        "y": lat,  # 위도(latitude)
        "radius": radius,
        "page": page,
        "size": size,
        "sort": "accuracy"
    }
    try:
        r = requests.get(KAKAO_LOCAL_CATEGORY, headers=headers, params=params, timeout=3)
        r.raise_for_status()
        return r.json()
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 403:
            try:
                error_data = e.response.json()
                error_msg = error_data.get("message", "인증 실패")
            except:
                error_msg = "인증 실패"
            raise Exception(f"카카오맵 API 인증 실패 (403): {error_msg}\n\n"
                          f"해결 방법:\n"
                          f"1. 카카오 개발자 센터(https://developers.kakao.com/) 접속\n"
                          f"2. 내 애플리케이션 선택 후 설정 탭 플랫폼 설정 플랫폼 메뉴\n"
                          f"3. 'Web 플랫폼 등록' 버튼 클릭 후 도메인 등록:\n"
                          f"   - http://localhost:5000\n"
                          f"   - http://127.0.0.1:5000\n"
                          f"   (또는 http://localhost:5173)\n"
                          f"4. 저장 후 5-10분 대기 (적용 시간 필요)\n"
                          f"5. backend_tmp/.env 파일에 KAKAO_REST_KEY=받은키_입력 입력\n"
                          f"6. 서버 재시작\n\n"
                          f"참고: Default REST API 키 사용 가능, 리다이렉트 URI는 필요 없습니다.")
        elif e.response.status_code == 401:
            raise Exception("카카오맵 API 키가 유효하지 않습니다. KAKAO_REST_KEY를 확인하세요.")
        else:
            raise Exception(f"카카오맵 API 오류 ({e.response.status_code}): {e.response.text}")
    except Exception as e:
        raise Exception(f"카카오맵 API 요청 실패: {str(e)}")

def kakao_keyword_search(query: str, lng: float, lat: float, radius: int, page: int = 1, size: int = 15):
    """키워드로 음식점 검색"""
    headers = get_headers()
    if not headers:
        raise Exception("KAKAO_REST_KEY가 설정되지 않았습니다.")
    
    params = {
        "query": query,
        "category_group_code": "FD6",  # 음식점만 검색
        "x": lng,
        "y": lat,
        "radius": radius,
        "page": page,
        "size": size,
        "sort": "distance"  # 거리순 정렬
    }
    try:
        r = requests.get(KAKAO_LOCAL_KEYWORD, headers=headers, params=params, timeout=3)
        r.raise_for_status()
        return r.json()
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 403:
            try:
                error_data = e.response.json()
                error_msg = error_data.get("message", "인증 실패")
            except:
                error_msg = "인증 실패"
            raise Exception(f"카카오맵 API 인증 실패 (403): {error_msg}\n\n"
                          f"해결 방법:\n"
                          f"1. 카카오 개발자 센터(https://developers.kakao.com/) 접속\n"
                          f"2. 내 애플리케이션 선택 후 설정 탭 플랫폼 설정 플랫폼 메뉴\n"
                          f"3. 'Web 플랫폼 등록' 버튼 클릭 후 도메인 등록:\n"
                          f"   - http://localhost:5000\n"
                          f"   - http://127.0.0.1:5000\n"
                          f"   (또는 http://localhost:5173)\n"
                          f"4. 저장 후 5-10분 대기 (적용 시간 필요)\n"
                          f"5. backend_tmp/.env 파일에 KAKAO_REST_KEY=받은키_입력 입력\n"
                          f"6. 서버 재시작\n\n"
                          f"참고: Default REST API 키 사용 가능, 리다이렉트 URI는 필요 없습니다.")
        elif e.response.status_code == 401:
            raise Exception("카카오맵 API 키가 유효하지 않습니다. KAKAO_REST_KEY를 확인하세요.")
        else:
            raise Exception(f"카카오맵 API 오류 ({e.response.status_code}): {e.response.text}")
    except Exception as e:
        raise Exception(f"카카오맵 API 요청 실패: {str(e)}")

def dedup_places(docs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """중복 제거: id > 이름+주소 > 이름+좌표 > 이름+유사한좌표 순으로 체크"""
    seen_by_id = set()
    seen_by_name_addr = set()
    seen_by_name_coord = set()
    out = []
    duplicate_count = 0
    
    for d in docs:
        # 카카오맵 API는 id 필드 없이 다른 필드를 사용할 수 있으므로 여러 필드 확인
        place_id = d.get("id") or d.get("place_id") or ""
        name = norm(d.get("place_name", ""))
        addr = norm(d.get("road_address_name", "") or d.get("address_name", ""))
        x = d.get("x")
        y = d.get("y")
        
        is_duplicate = False
        
        # 1) id가 있으면 id로 중복 체크 (가장 정확)
        if place_id:
            if place_id in seen_by_id:
                is_duplicate = True
                duplicate_count += 1
            else:
                seen_by_id.add(place_id)
        
        # 2) 이름 + 주소 조합으로 중복 체크 (주소가 있으면)
        if not is_duplicate and name and addr:
            name_addr_key = (name, addr)
            if name_addr_key in seen_by_name_addr:
                is_duplicate = True
                duplicate_count += 1
            else:
                seen_by_name_addr.add(name_addr_key)
        
        # 3) 이름 + 좌표로 중복 체크 (기본 방식)
        if not is_duplicate and name and x is not None and y is not None:
            # 좌표를 소수점 6자리로 반올림 (약 10cm 정확도)
            x_rounded = round(float(x), 6)
            y_rounded = round(float(y), 6)
            name_coord_key = (name, x_rounded, y_rounded)
            
            if name_coord_key in seen_by_name_coord:
                is_duplicate = True
                duplicate_count += 1
            else:
                seen_by_name_coord.add(name_coord_key)
                
                # 4) 이름이 같고 좌표가 매우 유사한 경우(20m 이내) 중복 제거
                if not is_duplicate:
                    for existing in out:
                        existing_name = norm(existing.get("place_name", ""))
                        existing_x = existing.get("x")
                        existing_y = existing.get("y")
                        
                        if (existing_name == name and 
                            existing_x is not None and existing_y is not None):
                            # 거리 계산 (약 20m 이내)
                            dist_m = haversine_m(float(y), float(x), float(existing_y), float(existing_x))
                            if dist_m < 20:  # 20m 이내면 같은 식당으로 간주
                                is_duplicate = True
                                duplicate_count += 1
                                break
        
        if not is_duplicate:
            out.append(d)
    
    return out

def to_place_item(doc: Dict[str, Any], base_lng: float, base_lat: float) -> Dict[str, Any]:
    name = doc.get("place_name","")
    address = doc.get("road_address_name") or doc.get("address_name") or ""
    tel = doc.get("phone","")
    x = float(doc.get("x", 0.0))
    y = float(doc.get("y", 0.0))
    dist = int(float(doc.get("distance", 0.0))) if doc.get("distance") else haversine_m(base_lat, base_lng, y, x)
    return {
        "name": name,
        "address": address,
        "tel": tel,
        "lat": y, "lng": x,
        "distance": dist,
        "kakaomap_link": f"https://map.kakao.com/link/search/{name}"
    }

# 좌표를 주소로 변환 (역지오코딩)
def kakao_coord2address(lng: float, lat: float) -> str:
    """카카오맵 API를 사용하여 좌표를 주소로 변환"""
    headers = get_headers()
    if not headers:
        return None
    
    params = {
        "x": lng,  # 경도
        "y": lat,  # 위도
        "input_coord": "WGS84"  # 입력 좌표계
    }
    
    try:
        r = requests.get(KAKAO_LOCAL_COORD2ADDRESS, headers=headers, params=params, timeout=3)
        r.raise_for_status()
        data = r.json()
        
        # 도로명 주소 우선, 없으면 지번 주소
        if data.get("documents") and len(data["documents"]) > 0:
            doc = data["documents"][0]
            address = doc.get("road_address", {}).get("address_name") or doc.get("address", {}).get("address_name")
            if address:
                return address
        return None
    except Exception as e:
        return None

# 거리 계산(m)
def haversine_m(lat1, lon1, lat2, lon2):
    R = 6371000
    p1 = math.radians(lat1); p2 = math.radians(lat2)
    dphi = math.radians(lat2-lat1); dl = math.radians(lon2-lon1)
    a = math.sin(dphi/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return int(R*2*math.atan2(math.sqrt(a), math.sqrt(1-a)))

# -------------------------
# API
# -------------------------

@app.get("/api/coord2address")
def coord2address():
    """좌표를 주소로 변환 (역지오코딩)"""
    try:
        x = float(request.args.get("x"))  # 경도
        y = float(request.args.get("y"))  # 위도
        
        # 좌표 보정 적용: 계산된 위치에서 오프셋을 적용하여 올바른 위치로 변환
        y, x = correct_coordinate(y, x)  # (lat, lng) 순서로 보정
        
        address = kakao_coord2address(x, y)
        if address:
            return jsonify({"address": address, "success": True})
        else:
            return jsonify({"address": None, "success": False, "message": "주소를 찾을 수 없습니다"})
    except Exception as e:
        return jsonify({"address": None, "success": False, "message": str(e)}), 500

@app.get("/api/categories")
def categories():
    # 프론트엔드 초기 로드시 카테고리 반환
    # 카테고리별 메뉴 목록을 반환 (frontend_tmp 형식)
    category_menus = {}
    
    # 한식 세부 카테고리 정보도 반환
    korean_subcategories = {}
    korean_all_menus = []
    
    for cat, menu_dict in MENU_INDEX.items():
        if cat.startswith("korean_"):
            # 한식 세부 카테고리
            korean_subcategories[cat] = list(menu_dict.keys())
            korean_all_menus.extend(menu_dict.keys())
        else:
            # 다른 카테고리
            category_menus[cat] = list(menu_dict.keys())
    
    # 한식은 전체를 하나로 묶음
    category_menus["korean"] = sorted(list(set(korean_all_menus)))
    
    return jsonify({
        "ok": True,
        "data": category_menus,
        "korean_subcategories": korean_subcategories,
        "korean_subcategory_labels": KOREAN_SUBCATEGORY_LABELS
    })

@app.get("/api/places")
def places():
    # 요청 파라미터
    menu = request.args.get("menu")
    x = float(request.args.get("x"))  # 경도 (longitude)
    y = float(request.args.get("y"))  # 위도 (latitude)
    
    # 좌표 보정 적용: 계산된 위치에서 오프셋을 적용하여 올바른 위치로 변환
    y, x = correct_coordinate(y, x)  # (lat, lng) 순서로 보정
    
    radius = int(request.args.get("radius", 2000))
    # 카카오 API는 최대 20000m(20km)까지만 허용
    if radius > 20000:
        radius = 20000
    # 프론트엔드에서 넘긴 cat 파라미터 우선 사용
    cat = request.args.get("cat") or guess_category_by_menu(menu)

    try:
        # 1) 메뉴별 브랜드 리스트 먼저 가져오기
        brands: List[str] = []
        # 한식인 경우 (cat이 "korean"이거나 "korean_*"로 시작하는 경우)
        if cat == "korean" or (cat and cat.startswith("korean_")):
            # 한식인 경우 모든 korean_* 서브카테고리에서 검색
            for subcat, menu_dict in MENU_INDEX.items():
                if subcat.startswith("korean_") and menu in menu_dict:
                    brands.extend(menu_dict[menu])
        else:
            # 다른 카테고리는 직접 검색
            brands = MENU_INDEX.get(cat, {}).get(menu, []) if cat else []
        
        # 디버깅: 브랜드가 없으면 로그 출력
        if not brands:
            print(f"[DEBUG] 메뉴 '{menu}' (카테고리: {cat})에 대한 브랜드를 찾을 수 없습니다.")
            print(f"[DEBUG] MENU_INDEX에 있는 카테고리: {list(MENU_INDEX.keys())[:10]}...")
            if cat and cat in MENU_INDEX:
                print(f"[DEBUG] 카테고리 '{cat}'에 있는 메뉴들: {list(MENU_INDEX[cat].keys())[:10]}...")
        
        # 2) 데이터셋에 있는 브랜드로 검색 (없으면 메뉴명으로 직접 검색)
        docs_all: List[Dict[str, Any]] = []
        
        if brands:
            print(f"[DEBUG] {len(brands)}개 브랜드로 검색 시작: {brands[:5]}...")
            for brand in brands[:10]:  # 최대 10개 브랜드 검색 (API 호출 제한)
                try:
                    j = kakao_keyword_search(brand, x, y, radius, page=1, size=15)
                    docs = j.get("documents", [])
                    docs_all.extend(docs)
                    print(f"[DEBUG] 브랜드 '{brand}': {len(docs)}개 결과")
                except Exception as e:
                    print(f"[DEBUG] 브랜드 '{brand}' 검색 실패: {e}")
                    pass
        else:
            # 브랜드가 없으면 메뉴명으로 직접 검색
            print(f"[DEBUG] 브랜드가 없어서 메뉴명 '{menu}'으로 직접 검색합니다.")
            try:
                j = kakao_keyword_search(menu, x, y, radius, page=1, size=15)
                docs_all.extend(j.get("documents", []))
                print(f"[DEBUG] 메뉴명 '{menu}' 검색: {len(j.get('documents', []))}개 결과")
            except Exception as e:
                print(f"[DEBUG] 메뉴명 '{menu}' 검색 실패: {e}")
                pass
        
        # 중복 제거 (API 응답 단계)
        base_docs = dedup_places(docs_all)
        print(f"[DEBUG] 중복 제거 후: {len(base_docs)}개 결과")

        # 3) 필터링 (브랜드가 있으면 브랜드 매칭, 없으면 메뉴명 포함 여부로 필터링)
        filtered: List[Dict[str, Any]] = []
        
        if brands:
            # 데이터셋에 있는 정확한 가게명만 매칭 (유성구 가게만 표시)
            brands_normalized = {norm(b): b for b in brands}  # 정규화된 전체 이름
            
            print(f"[DEBUG] 브랜드 매칭 시작: {len(base_docs)}개 결과 중에서 필터링")
            print(f"[DEBUG] 데이터셋에 있는 가게 수: {len(brands)}개")
            for d in base_docs:
                pname = d.get("place_name", "")
                if not pname:
                    continue
                
                pname_norm = norm(pname)
                
                # 정확한 이름 매칭만 사용 (데이터셋에 있는 가게만 표시)
                if pname_norm in brands_normalized:
                    filtered.append(to_place_item(d, x, y))
            
            print(f"[DEBUG] 브랜드 필터링 후: {len(filtered)}개 결과")
        else:
            # 브랜드가 없으면 메뉴명이 가게명이나 카테고리에 포함된 경우 필터링
            menu_norm = norm(menu) if menu else ""
            print(f"[DEBUG] 메뉴명 매칭 시작: {len(base_docs)}개 결과 중에서 필터링 (메뉴: '{menu}')")
            for d in base_docs:
                pname = d.get("place_name", "")
                category_name = d.get("category_name", "")
                
                if not pname:
                    continue
                
                pname_norm = norm(pname)
                category_norm = norm(category_name) if category_name else ""
                
                # 메뉴명이 가게명이나 카테고리에 포함되어 있으면 포함
                if menu_norm and (menu_norm in pname_norm or menu_norm in category_norm):
                    filtered.append(to_place_item(d, x, y))
                # 메뉴명이 없으면 모든 결과 포함 (안전장치)
                elif not menu_norm:
                    filtered.append(to_place_item(d, x, y))
            
            print(f"[DEBUG] 메뉴명 필터링 후: {len(filtered)}개 결과")
        
        # 최종 중복 제거 (변환 후 한 번 더 체크)
        filtered_deduped = []
        seen_final = set()
        for item in filtered:
            # 이름 + 주소로 최종 중복 체크
            name = norm(item.get("name", ""))
            addr = norm(item.get("address", ""))
            key = (name, addr) if addr else (name, item.get("lng"), item.get("lat"))
            
            if key not in seen_final:
                seen_final.add(key)
                filtered_deduped.append(item)
        
        filtered = filtered_deduped

        # 4) 거리순 정렬
        filtered.sort(key=lambda v: v.get("distance", 10**9))

        return jsonify({
            "ok": True,
            "count": len(filtered),
            "places": filtered
        })
    except Exception as e:
        error_msg = str(e)
        return jsonify({
            "ok": False,
            "error": error_msg,
            "count": 0,
            "places": []
        }), 500

def guess_category_by_menu(menu_id: str) -> str:
    for cat, menu_dict in MENU_INDEX.items():
        if menu_id in menu_dict:
            return cat
    return ""

@app.get("/api/recommend")
def recommend():
    # 랜덤 추천 (카테고리 선택 후 메뉴 선택)
    try:
        # 1단계: 카테고리 선택
        available_cats = [cat for cat, menus in MENU_INDEX.items() if menus]
        if not available_cats:
            return jsonify({"ok": False, "error": "사용 가능한 카테고리가 없습니다"})
        
        selected_cat = random.choice(available_cats)
        
        # 2단계: 선택된 카테고리에서 메뉴 선택
        # 한식인 경우 세부 구분 없이 전체 메뉴에서 선택
        if selected_cat.startswith("korean_"):
            # 한식 세부 카테고리면 모든 한식 메뉴에서 선택
            all_korean_menus = []
            for korean_cat in MENU_INDEX.keys():
                if korean_cat.startswith("korean_"):
                    all_korean_menus.extend(MENU_INDEX[korean_cat].keys())
            if all_korean_menus:
                selected_menu = random.choice(all_korean_menus)
                # 선택된 메뉴가 속한 세부 카테고리 찾기
                selected_sub = None
                for korean_cat, menus in MENU_INDEX.items():
                    if korean_cat.startswith("korean_") and selected_menu in menus:
                        selected_sub = korean_cat
                        break
                return jsonify({
                    "ok": True,
                    "category": "korean",
                    "subcategory": selected_sub,
                    "menu": selected_menu,
                    "menuId": selected_menu
                })
        else:
            # 다른 카테고리는 해당 카테고리에서 선택
            available_menus = list(MENU_INDEX[selected_cat].keys())
            if available_menus:
                selected_menu = random.choice(available_menus)
                return jsonify({
                    "ok": True,
                    "category": selected_cat,
                    "subcategory": None,
                    "menu": selected_menu,
                    "menuId": selected_menu
                })
        
        return jsonify({"ok": False, "error": "사용 가능한 메뉴가 없습니다"})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})

if __name__ == "__main__":
    app.run(debug=True, port=5000)
